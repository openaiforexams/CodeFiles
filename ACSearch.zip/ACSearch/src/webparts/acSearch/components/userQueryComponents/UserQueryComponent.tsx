import * as React from 'react';
import { Label } from '@fluentui/react';
import { Stack, IStackStyles, IStackTokens, IStackItemStyles } from '@fluentui/react/lib/Stack';
import SaveUserQueryComponent from './SaveUserQueryComponent';
import DeleteUserQueryComponent from './DeleteUserQueryComponent';
import LoadUserQueryComponent from './LoadUserQueryComponent';
const stackTokens: IStackTokens = { childrenGap: 5 };
const UserQueryComponent= ({ context }) => {
    const itemStyles: React.CSSProperties = {

        alignItems: 'flex-end',
     
        display: 'flex',
      
        height: 50,
      
        justifyContent: 'center',
      
        width: "auto",
        padding:"0px 10px"
      
      };
    
    return (
        <div className="ms-Grid" dir="ltr" style={{ padding: "15px 0px" }}>
            <div className="ms-Grid-row" style={{ borderBottom: '1px solid #eee' }}>
                <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                    <Label>User Search Query</Label>
                </div>
            </div>
            <div className="ms-Grid-row">
                <div className="ms-Grid-col ms-sm12 ms-md4 ms-lg4">

                <LoadUserQueryComponent context={context}  />

                </div>
                <div className="ms-Grid-col ms-sm12 ms-md8 ms-lg8">
                <Stack enableScopedSelectors horizontal>
          
                    <div style={itemStyles}><SaveUserQueryComponent context={context} /></div>
      
 
                    <div style={itemStyles}><DeleteUserQueryComponent context={context} /></div>
 


                </Stack>
                
                
                </div>
            </div>

        </div>
    );
}

export default UserQueryComponent;