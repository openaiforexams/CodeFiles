import * as React from 'react';
import { SearchContext } from '../../../hooks/SearchContext';
import { ITermInfo, ITermSetInfo, ITermStoreInfo } from "@pnp/sp/taxonomy";
import { ModernTaxonomyPicker } from "@pnp/spfx-controls-react/lib/ModernTaxonomyPicker";
import { ComboBox, IComboBoxOption, IComboBox, PrimaryButton } from '@fluentui/react';
import { ComboBoxListItemPicker, ListItemPicker } from '@pnp/spfx-controls-react/lib/ListItemPicker';
import Multiselect from 'multiselect-react-dropdown';
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import SearchService from '../../../services/SearchService';
export interface IComboBoxListItemPickerProps {
  context: any
  masterListURL:string
  listName:string
  codeColumnName:string
  nameColumnName:string
  managedProperties:any
  filterName:string
   label:string
   placeholder:string
}



var arr = [];
let Comboboxoptions: any;
const ComboboxFilter = ({ context,masterListURL,listName,codeColumnName,nameColumnName,managedProperties,filterName,label,placeholder}: IComboBoxListItemPickerProps) => {
  const [defaultCombobox, setDefaultCombobox] = React.useState([]);
  const [defatultComboboxOptions, setDefaultComboboxOptions] = React.useState([]);
  const [defatultComboboxIOptions, setDefaultComboboxIOptions] = React.useState([]);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  let webURL=masterListURL;
  React.useEffect(  () => {
    if (searchReducer.lastActionType == 'load' &&
      searchReducer.filters &&
      searchReducer.filters[filterName] &&
      searchReducer.filters[filterName].jsonValues
    ) {

      const selectedItems= searchReducer.filters[filterName].jsonValues.key;
      console.log(searchReducer.filters[filterName].jsonValues.options.map(item=> { return {key:item.key,text:item.text}}));
      setDefaultComboboxOptions(searchReducer.filters[filterName].jsonValues.options.map(item=> { return {key:item.key,text:item.text}}));
      setDefaultCombobox(selectedItems);


    }
    else if(searchReducer.lastActionType == 'load'||searchReducer.lastActionType == 'clear'){
      setDefaultComboboxOptions([]);
      setDefaultCombobox([]);
    }

  }, [searchReducer])

  let newKey = 1;
  
  const updateKqlQuery =  (event: React.FormEvent<IComboBox>, option?: IComboBoxOption, index?: number, value?: string) => {
      let Options,iOptions=[];
    if (option) {
      Options=option.selected ? [...defaultCombobox, option.key as string] :  defaultCombobox.filter(key => key !== option.key);
      iOptions=option.selected ? [...defatultComboboxIOptions, option]:  defatultComboboxIOptions.filter(key => key !== option.key);//.map(i => {`key:${i.key},text: ${i.text}`}); 
      console.log(iOptions);
      setDefaultComboboxIOptions(iOptions);
      setDefaultCombobox(Options);
    }

    let kqlText = '';;
    for (let i = 0; i < Options.length; i++) {

      for (let j = 0; j < managedProperties.length; j++) {
       const managedProp = managedProperties[j];

       let managedPropKqlText =`${managedProp}:"${Options[i]}"`;

       kqlText += i == 0 ? managedPropKqlText : ` OR ${managedPropKqlText}`
   }
   }    


  dispatchSearchReducer({ type: filterName, payload: { kqlText, jsonValues: {options:iOptions,key:Options} }})
  }
 
  const getChoiceFields = async (value) => {
    if(value!=undefined)
    {
   // const searchService = SearchService();
    let resultarr = [];
   let webURL=`${masterListURL}/_api/web/lists/GetByTitle('${listName}')/items?$top=10`;
    webURL+= value!=null && value!=""?`&$select=${codeColumnName},${nameColumnName}&$filter=substringof('${value}',${codeColumnName}) or substringof('${value}',${nameColumnName})`:'';
    await fetch(webURL, {
      method: 'GET',
      mode: 'cors',
      credentials: 'same-origin',
   
      headers: new Headers({
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Cache-Control': 'no-cache',
        'pragma': 'no-cache',

      }),

    }).then(async (response) => await response.json())
      .then(async (data) => {
        for (var i = 0; i < data.value.length; i++) {
          if(data.value[i][codeColumnName] !=null){
             resultarr.push({
              key: data.value[i][codeColumnName],
              text: data.value[i][codeColumnName] + "-" + data.value[i][nameColumnName]
            });
          }
         
        }

      });
     return resultarr;
    
    
    }
    

  };

  return (
  <ComboBox
      label={label}
      multiSelect
      placeholder={placeholder}
      options={defatultComboboxOptions}          
      autoComplete='off'
      allowFreeform={true}
      allowFreeInput={true}     
      onPendingValueChanged={(option,index,value) => {
        setDefaultComboboxOptions([]);
        getChoiceFields(value).then((items) => {
          if (items) {

            setDefaultComboboxOptions(items);
          }
          
        });
      } }
      selectedKey={defaultCombobox}  
      onChange={updateKqlQuery}
       />   
    
      
  );
}

export default ComboboxFilter;