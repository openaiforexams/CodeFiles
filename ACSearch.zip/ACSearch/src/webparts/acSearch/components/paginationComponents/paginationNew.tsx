
import * as React from 'react';
import { useState,useEffect } from 'react';

const Pagination = ({ data, itemsPerPage, Component }) => {
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  useEffect(() => {

    setTotalPages(Math.ceil(data.length / itemsPerPage));

  }, [data, itemsPerPage]);

  const handleClick = (pageNumber:any) => {

    setCurrentPage(pageNumber);

  };

  const renderItems = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;


    return data.slice(startIndex, endIndex).map((item:any) => (

      <Component key={item.id} item={item} />

    ));

  };



  const renderPageNumbers = () => {

    const pageNumbers = [];



    for (let i = 1; i <= totalPages; i++) {

      pageNumbers.push(

        <li key={i} className={currentPage === i ? 'active' : ''}>

          <button onClick={() => handleClick(i)}>{i}</button>

        </li>

      );

    }



    return pageNumbers;

  };



  return (

    <div>

      <ul>{renderItems()}</ul>

      <ul className="pagination">{renderPageNumbers()}</ul>

    </div>

  );

};



export default Pagination;

