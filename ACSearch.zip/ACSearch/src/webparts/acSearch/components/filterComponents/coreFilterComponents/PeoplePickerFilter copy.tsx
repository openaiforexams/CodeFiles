import * as React from 'react';
import { SearchContext } from '../../../hooks/SearchContext';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";  
import TextFieldFilter from './TextFieldFilter';

const PeoplePickerFilter = ({context, managedProperties = [], filterName, label}) => {
  const [defaultUsers, setDefaultUsers] = React.useState([]);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  React.useEffect(() => {

    if (searchReducer.lastActionType == 'load' &&
      searchReducer.filters &&
      searchReducer.filters[filterName] &&
      searchReducer.filters[filterName].jsonValues
    ) {

      const defUsers = searchReducer.filters[filterName].jsonValues.map((x: any) => x.secondaryText);
      setDefaultUsers(defUsers);

    } else if(searchReducer.lastActionType == 'load'||searchReducer.lastActionType == 'clear'){

      setDefaultUsers([]);
    }

  }, [searchReducer])

  const updateKqlQuery = (users: any[]) => {

    let kqlText = '';
    setDefaultUsers(users.map(i => i.text));
    for (let i = 0; i < users.length; i++) {

       for (let j = 0; j < managedProperties.length; j++) {
        const managedProp = managedProperties[j];

        let managedPropKqlText =`${managedProp}:"${users[i].text}" OR ${managedProp}:"${users[i].secondaryText}"`;

        kqlText += i == 0 ? managedPropKqlText : ` OR ${managedPropKqlText}`
    }
    }    
    dispatchSearchReducer({ type: filterName, payload: { kqlText, jsonValues: users.length>0?users:null } });
  }

  return (
    <><PeoplePicker
      titleText={label}
      placeholder={label}
      context={context}
      defaultSelectedUsers={defaultUsers}
      onChange={updateKqlQuery}
      personSelectionLimit={10}
      allowUnvalidated={true} />
      <div style={{paddingTop:"3px"}}></div>
      <TextFieldFilter 
      label={null}
        managedProperties={managedProperties}
        filterName={filterName+"freetext"}
        placeholder={"Free text for "+label} />
    </>
    
  );
}

export default PeoplePickerFilter;