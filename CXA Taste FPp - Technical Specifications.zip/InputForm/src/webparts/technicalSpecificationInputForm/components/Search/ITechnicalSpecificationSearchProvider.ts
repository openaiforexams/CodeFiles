import { sp } from "@pnp/sp";
import '@pnp/sp/webs';
import '@pnp/sp/lists';
import '@pnp/sp/items';
import '@pnp/sp/fields';
import "@pnp/sp/site-users/web";
import "@pnp/sp/folders/list";
import "@pnp/sp/files/folder";
import { IList } from "@pnp/sp/lists";
import { IFieldInfo } from "@pnp/sp/fields";
import { IItem } from "@pnp/sp/items";

import { isEmpty } from "@microsoft/sp-lodash-subset";
import TechnicalSpecificationSearch from "./TechnicalSpecificationSearch";
import { IDropdownOption } from '@fluentui/react/lib/Dropdown';

export const spListNames = {
    lst_initiatives: "Initiatives",
    lst_initiativeDocuments: "Initiative Documents",
    lst_revisonNumbers: "Revision Numbers",
    lst_documentTypes: "Document Types",
    lst_IDCO: "IDCO",
    lst_approvalHistorySME: "Approval History - SME",
    lst_approversOtherFunctions: "Approvers - Other functions",
    lst_approvalHistoryOtherFunctions: "Approval History - Other Functions",
    lst_approvalHistoryCX: "Approval History - CX",
    lst_approversCX: "Approvers - CX",
    lst_configurations: "Configurations",
}

export interface initiatives {
    ID?: number;
    Title: string;
    DocumentType: number,
    FileIDId: number;
    Revision: string;
    DocumentNumber: string;
    Description: string;
}
export interface initiativeDocuments {
    ID?: number;
    ProjectID: number;
}
export interface ITechnicalSpecificationSearchProvider {
    getcurrentUserGroups(filter): Promise<any[]>;
    getcurrentUserDetails(): Promise<any>;
    getSPListItems(filter, orderby, select, expand, listName): Promise<any>;
    getSPLookupColumnValues(listName, isLookup): Promise<IDropdownOption[]>;
    getSPChoiceColumnOptions(listName, fieldName): Promise<IDropdownOption[]>;
    getInitiativeDetails(ID): Promise<any>;
    getParameterByName(name);
    updateItem(listname, item, ID): Promise<any>;
    getUserProfileUrl(loginName): Promise<any>;
    getAllInitiativeDetails(): Promise<any>;
}
export default class TechnicalSpecificationSearchProvider implements ITechnicalSpecificationSearchProvider {
    public getcurrentUserGroups(filter): Promise<any[]> {
        return sp.web.currentUser.groups();
    }
    public getcurrentUserDetails(): Promise<any[]> {
        return sp.web.currentUser.get();
    }
    public getUserDetails(ID): Promise<any[]> {
        return sp.web.getUserById(ID).get();
    }
    public async getUserProfileUrl(loginName: string): Promise<any> {
        let userPictureUrl = await sp.profiles.getUserProfilePropertyFor(loginName, 'PictureURL');
        //console.log(userPictureUrl);
        return userPictureUrl.toString();
    }
    public getSPListItems(filter, orderby, select, expand, listName): Promise<any> {
        let filterItem = (filter === null ? '' : filter);
        let selectItem = (select === null ? '*' : select);
        return sp.web.lists
            .getByTitle(listName).items
            .select(selectItem)
            .filter(filterItem)
            .orderBy(orderby)
            .expand(expand)
            .getAll()
            .then(
                (items: any[]): any[] => {
                    return items;
                }
            );
    }
    public getSPLookupColumnValues(listName, isLookup): Promise<IDropdownOption[]> {
        return sp.web.lists
            .getByTitle(listName).items
            .orderBy("Title")
            .getAll()
            .then(
                (items: IDropdownOption[]): IDropdownOption[] => {
                    const ArrItems: IDropdownOption[] = [];
                    if (items !== null) {
                        items.forEach(
                            (item: any): void => {
                                if (isLookup) {
                                    ArrItems.push({
                                        key: item.ID,
                                        text: item.Title
                                    });
                                }
                                else {
                                    ArrItems.push({
                                        key: item.Title,
                                        text: item.Title
                                    });
                                }

                            });
                    }
                    return ArrItems;
                }
            );
    }
    public getSPChoiceColumnOptions(listName, fieldName): Promise<IDropdownOption[]> {
        let dropdownOption: IDropdownOption[] = [];
        return sp.web.lists
            .getByTitle(listName).fields.getByInternalNameOrTitle(fieldName).select("Choices").get()
            .then(
                (fieldInfo: IFieldInfo & { Choices: string[] }) => {
                    fieldInfo.Choices.map(item => { dropdownOption.push({ key: item, text: item }); });
                    return dropdownOption;
                });
    }
    public getInitiativeDetails(ID): Promise<any> {
        return sp.web.lists
            .getByTitle(spListNames.lst_initiatives).items.filter("ID eq " + ID)
            .select('*', 'DocumentType/Title', 'DocumentType/ID',
                'Author/EMail', 'Author/Title', 'Author/Name', 'Editor/Title', 'Editor/EMail', 'Editor/Name', 'IDCOApprover/Name', 'IDCOApprover/EMail', 'SME/EMail', 'SME/Title', 'SME/Id'
            ).expand('DocumentType', 'Author', 'Editor', 'IDCOApprover', 'SME').getAll().then(
                (item) => {
                    //console.log(item);
                    return item;
                });
    }
    public getAllInitiativeDetails(): Promise<any> {
      return sp.web.lists
          .getByTitle(spListNames.lst_initiatives).items
          .select('*', 'DocumentType/Title', 'DocumentType/ID',
              'Author/EMail', 'Author/Title', 'Author/Name', 'Editor/Title', 'Editor/EMail', 'Editor/Name', 'IDCOApprover/Name', 'IDCOApprover/EMail', 'SME/EMail', 'SME/Title', 'SME/Id','DocumentType/Title'
          ).expand('DocumentType', 'Author', 'Editor', 'IDCOApprover', 'SME','DocumentType').getAll().then(
              (item) => {
                  //console.log(item);
                  return item;
              });
  }
  
    public updateItem(listname, item, ID): Promise<any> {
        return sp.web.lists.
            getByTitle(listname).
            items.getById(ID).update(item).
            then((items): any => {
                return items;
            });
    }
    public getParameterByName(name, url = window.location.href) {
        name = name.replace(/[\[\]]/g, '\\$&');
        let regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        else if (!results[2]) return null;
        else return decodeURIComponent(results[2].replace(/\+/g, ' '));
    }

}
