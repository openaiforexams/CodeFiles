import * as React from 'react';
import { mergeStyles } from '@fluentui/react/lib/Styling';
import { Icon } from '@fluentui/react';
import { TooltipHost, ITooltipHostStyles } from '@fluentui/react/lib/Tooltip';
import { useId } from '@fluentui/react-hooks';

const styles: Partial<ITooltipHostStyles> = { root: { display: 'inline-block' } };
const calloutProps = { gapSpace: 0 };

const iconClass = mergeStyles({
    fontSize: 16,
    height: 16,
    width: 16,
    margin: '0 25px',
});

const iconWrapper = mergeStyles({
    position: 'relative',
    display: 'flex',
    justifyContent: 'end',
    alignItems: 'start',
    alignContent: 'center',
    alignSelf: 'center',
});

const badgeClass = mergeStyles({
    fontWeight: '600',
    position: 'absolute',
    display: 'flex',
    placeContent: 'center',
    alignItems: 'center',
    width: '20px',
    height: '12px',
    borderRadius:'15%',
    background: 'rgb(96, 94, 92)',
    color: 'rgb(255, 255, 255)',
    top: '10px',
    right: '10px',
    fontSize: '0.5rem',
});

const DocumentLocation = ({ item }) => {
    const tooltipId = useId(item.Id);
    const { Path, ACMatterCode } = item;

    let icon = 'Link';

    if (Path.indexOf('/teams/') !== -1) {
        icon = 'TeamsLogo16';
    }
    if (Path.indexOf('/sites/') !== -1) {
        icon = 'SharepointAppIcon16';
    }
    if (Path.indexOf('-my.sharepoint.com') !== -1) {
        icon = 'OneDriveLogo';
    }
    if (icon === 'Link' && Path.indexOf('.sharepoint.com') !== -1) {
        icon = 'SharepointAppIcon16';
    }

    return (
        <TooltipHost
            content={Path}
            // Give the user more time to interact with the tooltip before it closes
            closeDelay={500}
            id={tooltipId}
            calloutProps={calloutProps}
            styles={styles}
        >
            <div className={iconWrapper} >
                <Icon
                    iconName={icon}
                    className={iconClass}
                    aria-label="Location"
                    id={tooltipId}
                />
                {ACMatterCode && <span className={badgeClass}>DMS</span>}
            </div>
        </TooltipHost>
    );
}

export default DocumentLocation;