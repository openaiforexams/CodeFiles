import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface ITechnicalSpecificationInputFormProps {
  userDisplayName: string;
  context: WebPartContext;
  Title: string;
}
