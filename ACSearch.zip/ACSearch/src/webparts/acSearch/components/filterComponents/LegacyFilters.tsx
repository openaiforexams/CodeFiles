import * as React from 'react';

import TextFieldFilter from './coreFilterComponents/TextFieldFilter';
import { Label } from '@fluentui/react';

const LegacyFilters = ({ context }) => {
    return (
        <div className="ms-Grid" dir="ltr" style={{ padding: "15px 0px" }}>
            <div className="ms-Grid-row" style={{ borderBottom: '1px solid #eee' }}>
                <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                    <Label>Legacy Search Criteria</Label>
                </div>
            </div>
            <div className="ms-Grid-row">

                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                    <TextFieldFilter label='Legacy Document Number'
                        managedProperties={
                            ['ACLegacyDocNum']
                        }
                        filterName='legacyDocumentNumberFilter'
                        placeholder='Legacy Document Number' />
                </div>
                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                    <TextFieldFilter
                        placeholder={"Legacy Author"}
                        filterName="legacyauthorFilter"
                        label="Legacy Author"
                        managedProperties={
                            ["LegacyAuthorOWSTEXT"]
                        } />
                </div>
            </div>

        </div>
    );
}

export default LegacyFilters;