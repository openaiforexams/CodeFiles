import * as React from 'react';
import { SearchContext } from '../../../hooks/SearchContext';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import TextFieldFilter from './TextFieldFilter';
import { TextField } from '@fluentui/react';

const PeoplePickerFilter = ({ context, managedProperties = [], filterName, label }) => {
  const [defaultUsers, setDefaultUsers] = React.useState(null);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  React.useEffect(() => {

    if (searchReducer.lastActionType == 'load' &&
      searchReducer.filters &&
      searchReducer.filters[filterName] &&
      searchReducer.filters[filterName].jsonValues
    ) {

      const defUsers = searchReducer.filters[filterName].jsonValues;
      setDefaultUsers(defUsers);

    } else if (searchReducer.lastActionType == 'load' || searchReducer.lastActionType == 'clear') {

      setDefaultUsers(null);
    }

  }, [searchReducer])

  const updateKqlQuery = (usersString) => {

    let kqlText = '';
    setDefaultUsers(usersString);
    let users = usersString.split(",");
    if (usersString && usersString != null && usersString != "" && users.length > 0) {

      for (let i = 0; i < users.length; i++) {

        for (let j = 0; j < managedProperties.length; j++) {
          const managedProp = managedProperties[j];

          let managedPropKqlText = i==0 ?`${managedProp}:"*${users[i]}*"`:` OR ${managedProp}:"*${users[i]}*"`;

          kqlText += j == 0 ? managedPropKqlText : ` OR ${managedPropKqlText}`
        }
      }
    }
    else {
      for (let j = 0; j < managedProperties.length; j++) {
        const managedProp = managedProperties[j];

        let managedPropKqlText = usersString ? `${managedProp}:"${usersString}"` : '';

        kqlText += j == 0 ? managedPropKqlText : ` OR ${managedPropKqlText}`
      }
    }
    dispatchSearchReducer({ type: filterName, payload: { kqlText, jsonValues: users} });
  }

  return (
    <>
      <TextField
        label={label}
        styles={{ root: { borderRadius: "0px", width: '100%' } }}
        value={defaultUsers || ''}
        defaultValue={defaultUsers}
        onChange={(e, value) => updateKqlQuery(value)}
        placeholder={"For multiple users use ','(comma) as seperator"} />
    </>

  );
}

export default PeoplePickerFilter;