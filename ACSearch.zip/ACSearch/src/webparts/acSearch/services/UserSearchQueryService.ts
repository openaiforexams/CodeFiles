const UserSearchQueryService = ({ context }: any) => {


    const listName = 'User Search Queries';
    const listNameInPath = 'UserSearchQueries';

    const getSharePointDigest = async (serverRelativeUrl: string) => {
        const url = `${serverRelativeUrl}/_api/contextinfo`;
        const options = {
            method: 'POST',
            headers: {
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose'
            }
        };

        try {
            const response = await fetch(url, options);
            const data = await response.json();
            return data.d.GetContextWebInformation.FormDigestValue;
        } catch (error) {
            console.error(error);
        }
    }

    const saveSearchQuery = async (name: string, searchReducer: any) => {
        const { kqlText, serverRelativeUrl } = searchReducer;
        let url, header = null;
        const digest = await getSharePointDigest(serverRelativeUrl);
        let workspacePath=searchReducer.workspacePath&&searchReducer.workspacePath!=null?searchReducer.workspacePath:null
        const queryExists = await checkIfQueryExist(name, searchReducer,workspacePath);
        if (queryExists.length > 0) {
            url = `${serverRelativeUrl}/_api/web/getListByTitle('${listName}')/items(${queryExists[0].ListItemId})`;
            header = {
                'Accept': 'application/json;odata=none',
                'Content-Type': 'application/json;odata=none',
                'x-requestdigest': digest,
                'X-HTTP-Method': 'MERGE',
                'if-match': '*'
            }
        }
        else {
            url = `${serverRelativeUrl}/_api/web/getListByTitle('${listName}')/items`;
            header = {
                'Accept': 'application/json;odata=none',
                'Content-Type': 'application/json;odata=none',
                'x-requestdigest': digest,
                'if-match': '*'
            }
        }
        const options = {
            method: 'POST',
            headers: header,
            body: JSON.stringify({
                Title: name,
                KQLText: kqlText,
                QueryJSON: JSON.stringify({ searchReducer }),
                WorkspaceSearchPath:workspacePath
                //ServerRelativeUrl: serverRelativeUrl
            })
        };

        try {

            const response = await fetch(url, options);
            //const jsonData = await response.json();
            alert("Your search query was saved successfully");
            return;

        } catch (error) {
            alert("Error While saving search\n" + error)
            console.error(error);

            return;
        }
    }
    const deleteSearchQuery = async (id: number, searchReducer: any) => {
        const { kqlText, serverRelativeUrl } = searchReducer;
        let url, header = null;
        const digest = await getSharePointDigest(serverRelativeUrl);

            url = `${serverRelativeUrl}/_api/web/getListByTitle('${listName}')/items(${id})`;
            header = {              
                "Accept": "application/json;odata=verbose", 
                "X-RequestDigest": digest,      
                "IF-MATCH": "*",     
                "X-HTTP-Method": "DELETE" 
            }
       
        const options = {
            method: 'POST',
            headers: header,
            
        };

        try {

            const response = await fetch(url, options);
            //const jsonData = await response.json();
            alert("Your search query was deleted successfully");
            return;

        } catch (error) {
            alert("Error While deleting search query\n" + error)
            console.error(error);

            return;
        }
    }
    const checkIfQueryExist = async (name: string, searchReducer: any,workspacePath) => {
        const { serverRelativeUrl, absoluteUrl, user } = searchReducer;
        const url = `${serverRelativeUrl}/_api/search/postquery`;
        const digest = await getSharePointDigest(serverRelativeUrl);
        let queryText;
        if(workspacePath!=null)
        {
            queryText=`* AND Title:"${name}" AND path:${absoluteUrl}/lists/${listNameInPath} AND contentclass:STS_ListItem_GenericList AND (AuthorOWSUSER:"${user.email}" OR AuthorOWSUSER:"${user.displayName}")`;
        }
        const options = {
            method: 'POST',
            headers: {
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose',
                'x-requestdigest': digest
            },
            body: JSON.stringify({
                "request": {
                    'Querytext': `* AND Title:"${name}" AND path:${absoluteUrl}/lists/${listNameInPath} AND contentclass:STS_ListItem_GenericList AND (AuthorOWSUSER:"${user.email}" OR AuthorOWSUSER:"${user.displayName}")`,
                    //` AND (AuthorOWSUSER:"${user.email}" OR AuthorOWSUSER:"${user.displayName}" ) AND contentclass:STS_ListItem`,
                    'RowLimit': 100,
                    'SelectProperties': {
                        'results': [
                            'path',
                            'contentclass',
                            'AuthorOWSUSER',
                            'ListItemId',
                            'Title',
                            'Author'
                        ]
                    }
                }
            })
        };

        try {
            const result = []
            const response = await fetch(url, options);
            const jsonData = await response.json();

            const rawData = jsonData.d.postquery.PrimaryQueryResult.RelevantResults.Table.Rows.results;

            for (let i = 0; i < rawData.length; i++) {
                const item = {} as any;

                for (let j = 0; j < rawData[i].Cells.results.length; j++) {

                    const field = rawData[i].Cells.results[j];

                    item[field.Key] = field.Value;
                }

                result.push(item);
            }

            return result;

        } catch (error) {
            console.error(error);
            alert(error);
            return [];
        }

    }
    const getUserQueriesList = async (searchReducer: any) => {

        const { serverRelativeUrl, absoluteUrl, user,workspacePath } = searchReducer;

        const url = `${serverRelativeUrl}/_api/search/postquery`;
        const digest = await getSharePointDigest(serverRelativeUrl);
        let queryText=`* AND path:${encodeURI(`${absoluteUrl}/lists/${listNameInPath}`)} AND contentclass:STS_ListItem_GenericList AND (AuthorOWSUSER:"${user.email}" OR AuthorOWSUSER:"${user.displayName}")`;
       
        const options = {
            method: 'POST',
            headers: {
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose',
                'x-requestdigest': digest
            },
            body: JSON.stringify({
                "request": {
                    'Querytext': queryText,
                    //` AND (AuthorOWSUSER:"${user.email}" OR AuthorOWSUSER:"${user.displayName}" ) AND contentclass:STS_ListItem`,
                    'RowLimit': 100,
                    'SelectProperties': {
                        'results': [
                            'path',
                            'contentclass',
                            'AuthorOWSUSER',
                            'ListItemId',
                            'Title',
                            'Author',
                            'WorkspaceSearchPathOWSTEXT'
                        ]
                    }
                }
            })
        };
        
        try {
            const result = []
            const response = await fetch(url, options);
            const jsonData = await response.json();

            const rawData = jsonData.d.postquery.PrimaryQueryResult.RelevantResults.Table.Rows.results;

            for (let i = 0; i < rawData.length; i++) {
                const item = {} as any;

                for (let j = 0; j < rawData[i].Cells.results.length; j++) {

                    const field = rawData[i].Cells.results[j];

                    item[field.Key] = field.Value;
                }

                result.push(item);
            }
        if(workspacePath!=null)
        {
            return result.filter((resultitem)=>{ return resultitem.WorkspaceSearchPathOWSTEXT==workspacePath});
            
        }
        else{
            return result.filter((resultitem)=>{ return resultitem.WorkspaceSearchPathOWSTEXT==null ||  resultitem.WorkspaceSearchPathOWSTEXT==""});
        }

        } catch (error) {
            console.error(error);

            return [];
        }
    }
    const getUserQueriesListUsingListRestAPI = async (searchReducer: any) => {

        const { serverRelativeUrl, absoluteUrl, user,workspacePath } = searchReducer;

    

        const url = `${serverRelativeUrl}/_api/web/getListByTitle('${listName}')/items?$select=Title,KQLText,QueryJSON,WorkspaceSearchPath,Author/EMail,Id&$expand=Author&$filter=Author/EMail eq '${user.email}'`;
        const digest = await getSharePointDigest(serverRelativeUrl);

        const options = {
            method: 'GET',
            headers: {
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose',
                'x-requestdigest': digest
            },
        };

        try {

            const response = await fetch(url, options);
            const jsonData = await response.json();

            const result= jsonData.d.results;
            if(workspacePath!=null)
        {
            return result.filter((resultitem)=>{ return resultitem.WorkspaceSearchPath==workspacePath});
            
        }
        else{
            return result.filter((resultitem)=>{ return resultitem.WorkspaceSearchPath==null ||  resultitem.WorkspaceSearchPath==""});
        }

        } catch (error) {
            console.error(error);

            return;
        }
    }
    const getUserQueryById = async (id: string, searchReducer: any) => {

        const { serverRelativeUrl } = searchReducer;

        const url = `${serverRelativeUrl}/_api/web/getListByTitle('${listName}')/items(${id})`;
        const digest = await getSharePointDigest(serverRelativeUrl);

        const options = {
            method: 'GET',
            headers: {
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose',
                'x-requestdigest': digest
            },
        };

        try {

            const response = await fetch(url, options);
            const jsonData = await response.json();

            return jsonData.d;

        } catch (error) {
            console.error(error);

            return;
        }
    }
    return {
        saveSearchQuery,
        getUserQueriesList,
        getUserQueryById,
        checkIfQueryExist ,
        deleteSearchQuery,
        getUserQueriesListUsingListRestAPI
    }
}

export default UserSearchQueryService;