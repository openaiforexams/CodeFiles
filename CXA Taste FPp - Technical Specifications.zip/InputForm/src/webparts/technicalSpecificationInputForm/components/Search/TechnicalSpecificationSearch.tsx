import * as React from 'react';
import style from './TechnicalSpecificationSearch.module.scss';
import { ITechnicalSpecificationSearchProps } from './ITechnicalSpecificationSearchProps';
import { escape } from '@microsoft/sp-lodash-subset';

import { ITechnicalSpecificationSearchState } from './ITechnicalSpecificationSearchStates';
import { spListNames } from './ITechnicalSpecificationSearchProvider';
import TechnicalSpecificationSearchProvider, { ITechnicalSpecificationSearchProvider } from './ITechnicalSpecificationSearchProvider';

import Moment from 'react-moment';
Moment.globalFormat = 'DD/MM/YYYY hh:mm A';
import { Fabric, isDark, Stylesheet, Toggle } from 'office-ui-fabric-react';
import { IPersonaSharedProps, Persona, PersonaSize, PersonaPresence } from '@fluentui/react/lib/Persona';
import { containsInvalidFileFolderChars, sp } from "@pnp/sp/presets/all";
import { Dropdown, DropdownMenuItemType, IDropdownOption, IDropdownStyles } from '@fluentui/react/lib/Dropdown';
import { TextField, MaskedTextField, ITextFieldStyles } from '@fluentui/react/lib/TextField';
import { Checkbox, DetailsList, DetailsListLayoutMode, DocumentCard, DocumentCardActivity, DocumentCardDetails, DocumentCardPreview, DocumentCardTitle, DocumentCardType, ExpandingCard, ExpandingCardMode, FontWeights, HoverCard, HoverCardType, IColumn, IDocumentCardActivityPerson, IDocumentCardPreviewProps, IExpandingCardProps, ImageFit, IPlainCardProps, Link, mergeStyles, mergeStyleSets, MessageBar, MessageBarType, Pivot, PivotItem, SelectionMode, Spinner, Stack } from '@fluentui/react';
import { DatePicker, IDatePickerStyles, defaultDatePickerStrings, SpinButton, ISpinButtonStyles, Position } from '@fluentui/react';
import { Separator } from '@fluentui/react/lib/Separator';
import { Icon } from '@fluentui/react/lib/Icon';
import { PeoplePicker, PrincipalType } from "@pnp/spfx-controls-react/lib/PeoplePicker";
import { CommandBarButton, IconButton, DefaultButton, CommandButton } from '@fluentui/react/lib/Button';
import { Label } from '@fluentui/react/lib/Label';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BaseClientSideWebPart, BaseWebPartContext } from '@microsoft/sp-webpart-base';
import * as moment from 'moment';
require('./TechnicalSpecificationSearch.module.scss');

const logo: any = require('../../assets/welcome-dark.png');
const itemClasses = mergeStyleSets({
  selectors: {
    '&:hover': {
      textDecoration: 'underline',
      cursor: 'pointer',
      color: "red"
    },
  },
  hoverItem: {
    padding: "10px",
    'span': {
      fontSize: "11px"
    },
    fontSize: "12px"
  },
  label: {
    color: '#041e50',
    cursor: 'pointer'
  },
  cards: {
    maxWidth: '500px'
  }
});
const verticalStyle = mergeStyles({
  height: '200px',
});
const textFieldStyles: Partial<ITextFieldStyles> = { fieldGroup: { maxWidth: "100%", border: "none", borderBottom: "1px solid #C4c3cd" } };
const dropdownStyles: Partial<IDropdownStyles> = { title: { border: "none" }, dropdown: { maxWidth: "100%", border: "none", borderBottom: "1px solid #C4c3cd" } };
const datePickerStyles: Partial<IDatePickerStyles> = { root: { maxWidth: "100%", border: "none", borderBottom: "1px solid #C4c3cd" } };
const spinButtonStyles: Partial<ISpinButtonStyles> = { root: { maxWidth: "100%", border: "none", borderBottom: "1px solid #C4c3cd" } };
const loaderStyles = { root: { maxWidth: "100%", border: "none", Position: "relative", top: "40%" } };
const peoplePickerStyles = { text: { border: "none", borderBottom: "1px solid #C4c3cd" }, fieldGroup: { maxWidth: "100%", border: "none", borderBottom: "1px solid #C4c3cd" } };

const buttonStyles = {
  label: { color: "#041e50", fontWeight: "500" }
}
const pivotStyles = { itemContainer: { padding: "20px 10px" } }
export default class TechnicalSpecificationSearchComponent extends React.Component<ITechnicalSpecificationSearchProps, ITechnicalSpecificationSearchState, {}> {
  private importFileUploadRef: React.RefObject<HTMLInputElement>;
  private _Provider: ITechnicalSpecificationSearchProvider;
  constructor(props: ITechnicalSpecificationSearchProps) {
    super(props);
    sp.setup({
      spfxContext: this.props.context as any
    });
    this.state = {
      searchResults: [],
      selectedDocumentType: null,
      documentNumber: null,
      revision: null,
      selectedIDCO: null,
      title: null,
      status: null,
      dropdownDocumentTypeOptions: [],
      dropdownIDCOOptions: [],
      allIDCOOptions: [],
      currentUser: null,
      isShowLoader: false,
      searchResultColumns: [],
      showResults:false,
      showMessage:false
    };
    this.importFileUploadRef = React.createRef();
    this._onsearch = this._onsearch.bind(this);
  }
  public componentWillMount(): void {
    this._Provider = new TechnicalSpecificationSearchProvider();
  }
  public async componentDidMount() {
    try {
      const [documentTypeOptions, IDCOOptions, allIDCOs, currentUser] = await Promise.all([
        this._Provider.getSPLookupColumnValues(spListNames.lst_documentTypes, true),
        //this._Provider.getSPListItems("Category eq 'Admin'", "ID", "*,Responsible/Id,Responsible/EMail", "Responsible", spListNames.lst_configurations),
        this._Provider.getSPLookupColumnValues(spListNames.lst_IDCO, true),
        this._Provider.getSPListItems(null, 'ID', '*,Approver/Id,Approver/EMail,Approver/Name,Approver/Title', 'Approver', spListNames.lst_IDCO,),
        this._Provider.getcurrentUserDetails()
      ])
      this.setState({
        dropdownDocumentTypeOptions: documentTypeOptions,
        dropdownIDCOOptions: IDCOOptions,
        allIDCOOptions: allIDCOs,
        currentUser: currentUser,
      });
      console.log(this.state);
      //const initiativeItems = await this._Provider.getAllInitiativeDetails();

      //this._generateSearchResults(initiativeItems);
    }
    catch (error) {
      this._handlingException(error);
    }
  }
  public async _getInitiativeDetails() {
    this.setState({
      searchResults: null,
      selectedDocumentType: null,
      documentNumber: null,
      revision: null,
      selectedIDCO: null,
      title: null,
      status: null,
      dropdownDocumentTypeOptions: null,
      dropdownIDCOOptions: null,
      allIDCOOptions: null,
    });
    const initiativeItems = await this._Provider.getAllInitiativeDetails();
    initiativeItems.then(() => {
      //this._generateSearchResults();
    })
    let m = moment()
  }
  public _setCurrentUserRole(initiatives, stage) {
    let isUserApprover = false;
    let currentApprovalItem = 0;
    let isApprovalDone = false;
    initiatives.forEach(initiative => {
      if (this.state.currentUser.Id === initiative.PendingWithId) {
        isUserApprover = true;
        initiative.ReviewComments = initiative.ReviewComments === null ? "" : initiative.ReviewComments;
        currentApprovalItem = initiative
        if (initiative.Status === "Approved") {
          isApprovalDone = true;
          this.setState({});
        }
      }
    });

  }
  public _onControlChange = (ev: any, newValue: any): void => {
    let controlId = ev.target.id;
    switch (controlId) {
      case "title": this.setState({ title: newValue.toString() !== "" ? newValue.toString() : null });
        break;
      case "documentType": let item = newValue as IDropdownOption;
        let value = parseInt(item.key.toString());
        this.setState({ selectedDocumentType: value });
        break;
      case "idco_val":
        let selectedIDCOItem = newValue as IDropdownOption;
        if (!selectedIDCOItem) {
          return null;
        }
        let selectedIDCOVal = this.state.allIDCOOptions.filter(
          (idco) => idco.ID === selectedIDCOItem.key
        );
        let selectedIDCO = selectedIDCOVal[0];
        this.setState({
          selectedIDCO: parseInt(selectedIDCOItem.key.toString()),
          //selectedIDCOObj: { Description: selectedIDCO.Description, ApproverId: selectedIDCO.ApproverId, ApproverEmail: selectedIDCO.Approver.EMail }
        });
        break;
      case "documentNumber": this.setState({ documentNumber: newValue.toString() !== "" ? newValue.toString() : null });
        break;
      case "revision": this.setState({ revision: newValue.toString() !== "" ? newValue.toString().trim() : null });
        break;
      default: break;
    }
  }
 
  private _getKey(item: any, index?: number): string {
    return item.key;
  }
  public onRenderItemColumn = (item, index: number, column: IColumn): JSX.Element | React.ReactText => {
    const fieldContent = item[column.fieldName] as string;
    switch (column.key) {
      case "DocumentNumber":
        return (
          <><Link href={this.props.context.pageContext.web.absoluteUrl + "/SitePages/Initiative-Details.aspx?DocID=" + item.key}>{fieldContent}</Link></>
        );
      default: return fieldContent;

    }
    return item[column.key];
  };
  public async _onsearch(eventType): Promise<void> {
    try {
      if (eventType === 'Search') {
        let filter = "Status ne 'Requested' ";
        if (this.state.title !== null) {
          filter = filter + " and Title eq '" + this.state.title+"'";
        }
        if (this.state.selectedIDCO !== null && this.state.selectedIDCO !== '' ) {
          filter = filter + " and IDCOId eq " + this.state.selectedIDCO;
        }
        if (this.state.selectedDocumentType !== null && this.state.selectedDocumentType !== '') {
          filter = filter + " and DocumentTypeId eq " + this.state.selectedDocumentType;
        }
        if (this.state.revision !== null) {
          filter = filter + " and Revision eq '" + this.state.revision+"'";
        }
        if (this.state.documentNumber !== null) {
          filter = filter + " and DocumentNumber eq '" + this.state.documentNumber+"'";
        }
        console.log(filter);
        //getSPListItems(filter, orderby, select, expand, listName):
        let initiativeItems = await this._Provider.getSPListItems(filter, 'ID', "*,DocumentType/Title, DocumentType/ID,Author/EMail, Author/Title, Author/Name, Editor/Title, Editor/EMail, Editor/Name, IDCOApprover/Name, IDCOApprover/EMail, SME/EMail, SME/Title, SME/Id", "DocumentType, Author, Editor, IDCOApprover, SME", spListNames.lst_initiatives,);
        if(initiativeItems.length!==0){
          this.setState({showResults:true,showMessage:false});
          this._generateSearchResults(initiativeItems);
        }
        else{
          this.setState({showResults:false,showMessage:true})
        }
        
      }
      else if (eventType === 'Reset') {
        this.setState({
          searchResults: [],
          selectedDocumentType: '',
          documentNumber: null,
          revision: null,
          selectedIDCO: '',
          title: null,
          status: null,
          currentUser: null,
          isShowLoader: false,
          searchResultColumns: [],
          showResults:false,
          showMessage:false
        });
      }
    }
    catch (error) {
      this._handlingException(error);
    }
  }
  public _generateSearchResults(initiativeItems) {
    let items = [];
    initiativeItems.forEach(initiative => {
      items.push({
        key: initiative.ID,
        documentType: initiative.DocumentTypeId === null ? "" : initiative.DocumentType.Title,
        statusVal: initiative.Status,
        documentNumber: initiative.DocumentNumber,
        revision: initiative.Revision,

      });
    });
    let columns: IColumn[] = [

      {
        key: 'DocumentNumber',
        name: 'Document Number',
        fieldName: 'documentNumber',
        minWidth: 100,
        maxWidth: 200,
        isResizable: true,
      },
      {
        key: 'Revision',
        name: 'Revision',
        fieldName: 'revision',
        minWidth: 100,
        maxWidth: 200,
        isResizable: true,
      },
      {
        key: 'DocumentType',
        name: 'Document Type',
        fieldName: 'documentType',
        minWidth: 200,
        maxWidth: 200,
        isResizable: true,
      },
      {
        key: 'Status',
        name: 'Status',
        fieldName: 'statusVal',
        minWidth: 100,
        maxWidth: 200,
        isResizable: true,
      },

    ];
    this.setState({ searchResultColumns: columns });
    this.setState({ searchResults: items })
  }
  public _handlingException(error) {
    alert("There is an error\n" + error);
    console.log(error);
  }
  public render(): React.ReactElement<ITechnicalSpecificationSearchProps> {
    const {
      context,
      Title,
    } = this.props;

    return (
      <div>
        {this.renderSearchForm()}

      </div>
    );
  }

  public renderSearchForm = (): JSX.Element => {
    return (
      <Fabric className={style.boxShadow} >
        <div className={style.gridContainer}>
          {this.state.isShowLoader && (
            <div className={style.loaderDiv}>
              <Spinner styles={loaderStyles} label="Please wait.." />
            </div>
          )}
          <div className=" row">

            <div className={"col-lg-12 "}>
              <div className={"row " + style.sectionDetails}>
                <div className='col-12'>
                  <div id="searchSection" className={" row disabled "} >
                    <div className={style.fieldCols + " col-lg-4 col-md-4 col-sm-6"}>
                      <TextField id="documentNumber" label="Document Number" defaultValue={this.state.documentNumber} placeholder="" styles={textFieldStyles} value={this.state.documentNumber} onChange={this._onControlChange} required={true} />
                    </div>
                    <div className={style.fieldCols + " col-lg-4 col-md-4 col-sm-6"} >
                      <TextField id="revision" label="Revision" defaultValue={this.state.revision} value={this.state.revision} placeholder="" onChange={this._onControlChange} styles={textFieldStyles} required={true} />
                    </div>
                    <div className={style.fieldCols + " col-lg-4 col-md-4 col-sm-6"}>
                      <TextField id="title" label="Title" defaultValue={this.state.title} value={this.state.title} onChange={this._onControlChange} styles={textFieldStyles} required={true} />
                    </div>
                    <div className={style.fieldCols + " col-lg-4 col-md-4 col-sm-6"}>
                      <Dropdown
                        id="documentType"
                        required={true}
                        label="Document Type"
                        selectedKey={this.state.selectedDocumentType !== null ? this.state.selectedDocumentType : undefined}
                        onChange={this._onControlChange}
                        placeholder="Select Document Type"
                        options={this.state.dropdownDocumentTypeOptions}
                        styles={dropdownStyles}
                      />
                    </div>
                    <div className={style.fieldCols + " col-lg-4 col-md-4 col-sm-6"} >
                      <Dropdown
                        id="idco_val"
                        required={true}
                        label="IDCO"
                        selectedKey={this.state.selectedIDCO !== null ? this.state.selectedIDCO : undefined}
                        onChange={this._onControlChange}
                        placeholder="Select IDCO"
                        options={this.state.dropdownIDCOOptions}
                        styles={dropdownStyles}
                      />
                    </div>

                  </div>
                </div>
              </div>

              <div className={"row " + style.sectionButtons}>
                <div className={style.fieldCols + " col-lg-12 col-md-12 col-sm-12"}>
                  <CommandBarButton style={{ display: 'inline-block' }} styles={buttonStyles} className={style.button} primary={true} text="Search" onClick={() => { this._onsearch("Search").then(() => { }).catch(() => { }); }} />
                  <CommandBarButton style={{ display: 'inline-block' }} styles={buttonStyles} className={style.button} primary={true} text="Reset" onClick={() => { this._onsearch("Reset").then(() => { }).catch(() => { }); }} />
                </div>
              </div>


            </div>
            <Separator />
            <div className="col-12">
              {this.state.showResults && (
                <DetailsList
                items={this.state.searchResults}
                compact={false}
                columns={this.state.searchResultColumns}
                selectionMode={SelectionMode.none}
                getKey={this._getKey}
                setKey="none"
                layoutMode={DetailsListLayoutMode.justified}
                isHeaderVisible={true}
                onRenderItemColumn={this.onRenderItemColumn}
              />
              ) || 
              this.state.showMessage && (
                <p>No results found</p>
              )}
              
            </div>
          </div>
        </div>
      </Fabric >
    )
  }
  public rednderLoader = (): JSX.Element => {
    return (
      <div>
        <Spinner label="Please wait.. Form is loading..." />
      </div>
    )
  }
}
