import * as React from 'react';
// import { SPUser } from '@microsoft/sp-page-context';
import { Toggle } from '@fluentui/react/lib/Toggle';
import { BaseComponentContext } from '@microsoft/sp-component-base';
import FileTypeFilter from './filterComponents/FileTypeFilter';
import DocumentTypeFilter from './filterComponents/DocumentTypeFilter';
import RestrictSearchTo from './filterComponents/RestrictSearchTo';
import ClientFilter from './filterComponents/ClientFilter';
import LookforFilter from './filterComponents/LookforFilter';
import EmailFilters from './filterComponents/EmailFilters';
import PeoplePickerFilter from './filterComponents/coreFilterComponents/PeoplePickerFilter';
import TextFieldFilter from './filterComponents/coreFilterComponents/TextFieldFilter';
import DateFieldFilter from './filterComponents/coreFilterComponents/DateFieldFilter';
import { IAcSearchWebPartProps } from '../AcSearchWebPart';
import ComboboxFilter from './filterComponents/coreFilterComponents/ComboboxFilter';
import ComboBoxListItemPickerComp from './filterComponents/coreFilterComponents/ComboBoxListItemPickerComp';
import { SearchContext } from '../hooks/SearchContext';
import { Link, PrimaryButton, selectProperties } from '@fluentui/react';
import LegacyFilters from './filterComponents/LegacyFilters';
import styles from './AcSearch.module.scss'
import UserQueryComponent from './userQueryComponents/UserQueryComponent';
export interface IAcSearchAdvancedOptions {
  context: BaseComponentContext
  webpartProperities:IAcSearchWebPartProps
  WorkSpacePath:string
}

const AcSearcAdvancedOptons = ({ context,webpartProperities,WorkSpacePath}: IAcSearchAdvancedOptions) => {
  const [openAdvanced, setOpenAdvanced] = React.useState(false);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  return (

    <>
      <div style={
        { padding: "10px 0px" }
      }>
        <div style={{float:"left"}}>
        <Toggle label="Advanced Options" inlineLabel
          checked={openAdvanced}
          onChange={
            (e) => {
            setOpenAdvanced(!openAdvanced);
            let  kqlText ='contenttypeid:0x01010000F35FC355F0AE488312404DD8630FEA* OR contenttype:"AC Document Legacy" OR contenttype:"AC Email" OR contenttype:"AC Email Legacy"';
            dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues:'Documents & Emails'},searchResultView:'defaultView'})
            }
          } />
          </div>
          <div style={{float:"right",paddingRight:"16px"}}>
        {searchReducer.filters &&
          <PrimaryButton 
          styles={{root:{borderradius:"0px",width: "84px"}}}
          onClick={()=>{
            let  kqlText =""
            dispatchSearchReducer({ type: 'clear', payload: {kqlText, jsonValues:''}})
          }} 
          text={"Clear"}

          />
        }
          </div>
          <div style={{clear:"both"}}></div>
      </div>

      {
        openAdvanced && <div className={styles.grid +"ms-Grid"} dir="ltr">
          <div className={"ms-Grid-row grid"}>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              <DateFieldFilter label='Date Created'
                managedProperties={
                  ['Created']
                }
                filterName='createdDateFilter' />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              <DateFieldFilter label='Date Modified'
                managedProperties={
                  ['LastModifiedTimeForRetention']
                }
                filterName='modifiedDateFilter' />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              <FileTypeFilter />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              <PeoplePickerFilter context={context}
                filterName="createdByFilter"
                label="Created By"
                managedProperties={
                  ["AuthorOWSUSER"]
                } />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              <PeoplePickerFilter context={context}
                filterName="authorFilter"
                label="Author"
                managedProperties={
                  ["AuthorOWSUSER"]
                } />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              {
                
                <DocumentTypeFilter context={context} termID={webpartProperities.documentTypeTermId} />
              }
              
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              <TextFieldFilter label='Document Number'
                managedProperties={
                  ['ACDocumentId']
                }
                filterName='documentIDFilter'
                placeholder='Document Number' />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              <RestrictSearchTo />
            </div>
           
            {
             WorkSpacePath==null?
             
            <><div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
                <ComboboxFilter context={context} 
                masterListURL={webpartProperities.masterListSiteURL}
                      managedProperties={['ACClientCode']}
                      codeColumnName='ClientCode'
                      nameColumnName='ClientName'
                      filterName='clientFilter'
                      label='Client'
                      placeholder='Enter the keyword and select...'
                      listName='Clients List'
                      
                      />
                </div>
                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
               <ComboboxFilter context={context} 
                masterListURL={webpartProperities.masterListSiteURL}
                      managedProperties={['ACMatterCode']}
                      codeColumnName='MatterCode'
                      nameColumnName='MatterName'
                      filterName='workspaceCodeFilter'
                      label='Workspace Code'
                      placeholder='Enter the keyword and select...'
                      listName='Matters List'
                      
                      />
               
                  </div></>
            :null
            }
            <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg4">
              <LookforFilter />
            </div>
            
            <div className="ms-Grid-col ms-sm12 ms-md12">
              <EmailFilters context={context} />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md12">
              <LegacyFilters context={context} />
            </div>
            <div className="ms-Grid-col ms-sm12 ms-md12">
              <UserQueryComponent context={context} />
            </div>
          </div>

          
      
        </div>
      } </>
  );
}

export default AcSearcAdvancedOptons;
