import { TermActionsDisplayStyle } from "@pnp/spfx-controls-react";
import { DateFormat } from "@pnp/spfx-controls-react/lib/controls/dynamicForm/dynamicField/IDynamicFieldProps";

export interface ITechnicalSpecificationSearchState{
    searchResults:any;
    selectedDocumentType:any;
    documentNumber:any;
    revision:any;
    selectedIDCO:any;
    title:any;
    status:any;
    dropdownDocumentTypeOptions:any,
    dropdownIDCOOptions,
    allIDCOOptions:any,
    currentUser:any,
    isShowLoader:boolean,
    searchResultColumns:any,
    showResults:boolean,
    showMessage:boolean,
}
export interface IUserDetails{
    ID?:number;
    loginName:string;
    email:string;
}
export interface ISpfxPnpPeoplepickerState {
    SuccessMessage: string;
    UserDetails: IUserDetails[];
    selectedusers: string[];

}




