import * as React from 'react';
import { SearchContext } from '../../hooks/SearchContext';
import { Dropdown, IDropdownStyles, IDropdownOption } from '@fluentui/react/lib/Dropdown';

const dropdownStyles: Partial<IDropdownStyles> = {

};

const sortOption: IDropdownOption[] = [
    { key: null, text: 'Relevance', isSelected: true },
    { key: 'LastModifiedTimeForRetention', text: 'Last Modified Date' },
    { key: 'Created', text: 'Created Date' } ,
    { key: 'Filename', text: 'Document Name' } ,
];

const SortingDropdown = () => {
const [selectedSortoptions,setSelectedSortOptions]= React.useState<string>(null);

  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);

  React.useEffect(() => {
    
      if (searchReducer.lastActionType == 'load' &&
      searchReducer.sort
    ) {
    
      setSelectedSortOptions(searchReducer.sort);

    } else if (searchReducer.lastActionType == 'load') {

      setSelectedSortOptions(null);
    }

  }, [searchReducer])

  const updateKqlQuery= (event: React.FormEvent<HTMLDivElement>, option: IDropdownOption): void=>{
    let kqlText = "";
    if (option) {
      setSelectedSortOptions(option.key as string);
    }   
      dispatchSearchReducer({ type: 'sort',sort:option.key })
    
  }

  return (

    <Dropdown
placeholder="Select options"
label="Sort By"
options={sortOption}
selectedKey={selectedSortoptions}
styles={dropdownStyles}
 onChange={updateKqlQuery}
/>



  );
}

export default SortingDropdown;