import * as React from 'react';

import { SearchContext } from '../../hooks/SearchContext';
import { Dropdown, IDropdownOption } from '@fluentui/react/lib/Dropdown';
import UserSearchQueryService from '../../services/UserSearchQueryService';

const LoadUserQueryComponent =  ({context}:any) => {
    const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
    const [options, setOptions] = React.useState([] as IDropdownOption[]);
    const [selectedOption, setSelectedOption] = React.useState(null);
    const userSerchService = UserSearchQueryService(context);

    React.useEffect(() => {
        (async () => {
            const data = await userSerchService.getUserQueriesListUsingListRestAPI(searchReducer);
            const list = [];
            for (let i = 0; i < data.length; i++) {
                list.push({ key: data[i].Id, text: data[i].Title });
            }
            
            if(searchReducer.lastActionType == 'userquerylist'||searchReducer.lastActionType == 'clear') {

                setSelectedOption(null);
              }
             else if(searchReducer.lastActionType != 'userquerylist') {

                 dispatchSearchReducer({type:"userquerylist",jsonValue:list});
              }
             
        })();
    }, [searchReducer]);


    const loadKQLQuery = async (e: any, selectedValue: IDropdownOption) => {
        const { QueryJSON } = await userSerchService.getUserQueryById(selectedValue.key as string, searchReducer);
        setSelectedOption(selectedValue.key as string)
        dispatchSearchReducer({ type: 'load', payload: JSON.parse(QueryJSON),loadedID:selectedValue.key as string,loadedQueryName:selectedValue.text as string });
    }
    return (
        <>
            {  //          options && options.length > 0 &&
                <Dropdown
                    selectedKey={searchReducer&&searchReducer.loadedID?searchReducer.loadedID:null}
                    placeholder="Select options"
                    label="Load Saved Search Query"
                    options={searchReducer&&searchReducer.userQueryList?searchReducer.userQueryList:[]}
                    onChange={loadKQLQuery}
                />
         }
        </>
    );
}

export default LoadUserQueryComponent;