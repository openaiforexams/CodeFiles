import * as React from 'react';
import { SearchContext } from '../../hooks/SearchContext';
import { ITermInfo, ITermSetInfo, ITermStoreInfo } from "@pnp/sp/taxonomy";
import { ModernTaxonomyPicker } from "@pnp/spfx-controls-react/lib/ModernTaxonomyPicker";
import { ComboBox, IComboBoxOption, IComboBox, PrimaryButton } from '@fluentui/react';
import { ComboBoxListItemPicker, ListItemPicker } from '@pnp/spfx-controls-react/lib/ListItemPicker';
export interface IComboBoxListItemPickerProps {
  context: any

}



var arr = [];
let clientoptions: any;
const ClientFilter = ({ context }: IComboBoxListItemPickerProps) => {
  const [defaultUsers, setDefaultUsers] = React.useState([]);
  const [defaultClient, setDefaultClient] = React.useState([]);
  const [defatultClientOptions, setDefaultClientOptions] = React.useState([]);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  let webURL = 'https://arthurcox.sharepoint.com.mcas.ms/sites/idspDEV'
  React.useEffect(() => {
    //debugger;



    clientoptions = getChoiceFields(webURL, "Client List").then(items => {
      if (items.length > 0) {
        setDefaultClientOptions(items);
      }
    });
   

    if (searchReducer.lastActionType == 'load' &&
      searchReducer.filters &&
      searchReducer.filters.clientFilter &&
      searchReducer.filters.clientFilter.jsonValues
    ) {

      const defUsers = searchReducer.filters.clientFilter.jsonValues.map((x: any) => x.secondaryText);
      setDefaultUsers(defUsers);

    } else if(searchReducer.lastActionType == 'load'||searchReducer.lastActionType == 'clear'){

      setDefaultUsers([]);
    }

  }, [searchReducer])

  let newKey = 1;
  
  const updateKqlQuery = (event: React.FormEvent<IComboBox>, option?: IComboBoxOption, index?: number, value?: string): void => {
    let Options=[];
    if (option) {
      Options=option.selected ? [...defaultClient, option.key as string] :  defaultClient.filter(key => key !== option.key);  
      setDefaultClient(Options);
    }

    let kqlText = '';;
    Options.map((item:any,i:number)=>{
      kqlText += `ACClientCode:"${item!=null?item.split('-')[0]:item}" ${i < Options.length - 1 ? ` OR ` : ''}`;
    });

    dispatchSearchReducer({ type: 'clientFilter', payload: { kqlText, jsonValues: Options } })
  }
 

  const getChoiceFields = async (webURL, field) => {

    let resultarr = [];

    await fetch(`${webURL}/_api/web/lists/GetByTitle('Clients List')/items'`, {

      method: 'GET',

      mode: 'cors',

      credentials: 'same-origin',

      headers: new Headers({

        'Content-Type': 'application/json',

        'Accept': 'application/json',

        'Access-Control-Allow-Origin': '*',

        'Cache-Control': 'no-cache',

        'pragma': 'no-cache',

      }),

    }).then(async (response) => await response.json())
      .then(async (data) => {
        for (var i = 0; i < data.value.length; i++) {
          if(data.value[i].ClientCode !=null){
            await resultarr.push({
              key: data.value[i].ClientCode + "-" + data.value[i].ClientName,
              text: data.value[i].ClientCode + "-" + data.value[i].ClientName
            });
          }
         
        }

      });

    return await resultarr;

  };

  return (
 
      <ComboBox
        placeholder="Select ..."
        selectedKey={defaultClient}
        label="Client"
        autoComplete="on"
        allowFreeform
        multiSelect
        options={defatultClientOptions}
        onChange={updateKqlQuery}
      />

  );
}

export default ClientFilter;