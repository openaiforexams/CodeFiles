import * as React from 'react';
import { SearchContext } from '../../hooks/SearchContext';
import { Dropdown, IDropdownStyles, IDropdownOption } from '@fluentui/react/lib/Dropdown';
import { Label, TextField } from '@fluentui/react';

const dropdownStyles: Partial<IDropdownStyles> = {

};

const options: IDropdownOption[] = [
  
  { key: 'Documents & Emails', text: 'Documents & Emails' },
  { key: 'Emails Only', text: 'Emails Only'},
  { key: 'Documents Only', text: 'Documents Only'},
  { key: 'Everything', text: 'Everything' }
];

const RestrictSearchTo = () => {
  const [selectedOption, setSelectedOption] = React.useState<string>("Documents & Emails");
  const [textFieldValue, setTextFieldValue] = React.useState(null);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  
  React.useEffect(() => {
    
    if ((searchReducer.lastActionType == 'load' || searchReducer.lastActionType == 'restrictSearchTo') &&
      searchReducer.filters &&
      searchReducer.filters.restrictSearchTo &&
      searchReducer.filters.restrictSearchTo.jsonValues
    ) {
  
      setSelectedOption(searchReducer.filters.restrictSearchTo.jsonValues);

    } else if (searchReducer.lastActionType == 'load') {

      setSelectedOption(null);
    }
    else if(searchReducer.lastActionType == 'clear')
    {
      setSelectedOption("Documents & Emails");
      let kqlText ='contenttypeid:0x01010000F35FC355F0AE488312404DD8630FEA* OR contenttype:"AC Document Legacy" OR contenttype:"AC Email" OR contenttype:"AC Email Legacy"';
      dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues:"Documents & Emails"},searchResultView:'defaultView'})

    }

  }, [searchReducer])

  const updateKqlQuery= (event: React.FormEvent<HTMLDivElement>, option: IDropdownOption): void=>{
    let kqlText = "";
    if (option) {
      setSelectedOption(option.key as string);
    }   
    if (option.key as string == "Emails Only") {
      kqlText += 'contenttype:"AC Email" AND FileExtension:"msg"';
      dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues:option.key as string},searchResultView:'emailView'})
    }
    else if(option.key as string == "Documents Only") {
      kqlText +='(contenttypeid:0x01010000F35FC355F0AE488312404DD8630FEA* OR contenttype:"AC Document Legacy") NOT FileExtension:"msg"';
      dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues:option.key as string},searchResultView:'defaultView'})
    }
    else if(option.key as string == "Documents & Emails") {
      kqlText +='contenttypeid:0x01010000F35FC355F0AE488312404DD8630FEA* OR contenttype:"AC Document Legacy" OR contenttype:"AC Email" OR contenttype:"AC Email Legacy"';
      dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues:option.key as string},searchResultView:'defaultView'})
    }

    else{
      kqlText = null;
      dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues: "Everything" },searchResultView:'defaultView' })
    }
  }

  return (

          <Dropdown placeholder="Select options"
           // disabled={textFieldValue==null} 
           label="Restrict Search To"
            options={options}
            selectedKey={selectedOption}
            styles={dropdownStyles}
            onChange={updateKqlQuery}/>
  );
}

export default RestrictSearchTo;