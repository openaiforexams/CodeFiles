import * as React from 'react';
import { PrimaryButton } from '@fluentui/react/lib/Button';
import { SearchBox } from '@fluentui/react/lib/SearchBox';


import { SearchContext } from '../../hooks/SearchContext';
import styles from '../AcSearch.module.scss';

export const SearchBoxComponent = () => {
    const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
    const [keywords, setKeywords] = React.useState(null);

    React.useEffect(() => {

        if (searchReducer.lastActionType == 'load' && searchReducer.keywords !== '*') {
            setKeywords(searchReducer.keywords);
        }
    }, [searchReducer])

    const updateKeywords = () => {
        let  kqlText ='contenttypeid:0x01010000F35FC355F0AE488312404DD8630FEA* OR contenttype:"AC Document Legacy" OR contenttype:"AC Email" OR contenttype:"AC Email Legacy"';
        dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues:'Documents & Emails'},searchResultView:'defaultView'})
       
        dispatchSearchReducer({ type: 'setKeywords', payload: { value: keywords } });
    }

    return (
        <>
        <div>
            <div className={styles.searchBox}>
            <SearchBox
            styles={{root:{borderRadius:"0px"}}}
                        placeholder="Search"
                        onSearch={updateKeywords}
                        onChange={(e, value) => setKeywords(value)}
                        value={keywords || ''}
                        defaultValue={keywords} />

            </div>
            <div className={styles.searchButton}>
            <PrimaryButton text="Search" onClick={updateKeywords} />
            </div>
        </div>

            </>
        
    );
}