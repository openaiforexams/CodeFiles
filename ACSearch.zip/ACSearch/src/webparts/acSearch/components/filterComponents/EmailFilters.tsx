import * as React from 'react';

import TextFieldFilter from './coreFilterComponents/TextFieldFilter';
import DateFieldFilter from './coreFilterComponents/DateFieldFilter';
import { Label } from '@fluentui/react';
import { SearchContext } from '../../hooks/SearchContext';

const EmailFilters = ({ context }) => {
    const { dispatchSearchReducer } = React.useContext(SearchContext);
    
    const changeToEmailView = () => {
        dispatchSearchReducer({ type: 'ViewfileTypeFilter', payload: { kqlText: '', jsonValues: null }, searchResultView: 'emailView' });

        // changing to email view will also flip the restrictSearchTo filter to 'Emails Only'
        const kqlText = 'contenttype:"AC Email" AND FileExtension:"msg"';
        dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues: "Emails Only" as string }, searchResultView: 'emailView' })
    }

    return (
        <div className="ms-Grid" dir="ltr" style={{ padding: "15px 0px" }}>
            <div className="ms-Grid-row" style={{ borderBottom: '1px solid #eee' }}>
            <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
                <Label>E-mail Search Criteria</Label>
            </div>
            </div>
            <div className="ms-Grid-row">

                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                <TextFieldFilter
                        label='From'
                        managedProperties={['IntappFromOWSTEXT', 'RefinableString02']}
                        filterName='emailFromFilter'
                        placeholder='Specify Email Address'
                        onChange={changeToEmailView}
                    />
                   
                </div>
                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                <TextFieldFilter
                        label='To'
                        managedProperties={['IntappToOWSMTXT', 'RefinableString01']}
                        filterName='emailToFilter'
                        placeholder='Specify Email Address'
                        onChange={changeToEmailView}
                    />
                </div>
                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                    <DateFieldFilter
                        label='Date Sent'
                        managedProperties={['RefinableDateSingle01']} 
                        filterName='emailDateSentFilter'
                        onChange={changeToEmailView}
                    />
                </div>
                <div className="ms-Grid-col ms-sm12 ms-md6 ms-lg6">
                    <DateFieldFilter
                        label='Date Received'
                        managedProperties={['RefinableDateSingle02']}
                        filterName='emailDateReceivedFilter'
                        onChange={changeToEmailView}
                    />
                </div>
            </div>
            
        </div>
    );
}

export default EmailFilters;