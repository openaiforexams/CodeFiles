import * as React from 'react';
import { Link } from '@fluentui/react';

const DocumentLink = ({ item, children, style = {}, onClick = null }) => {
    const { Path, serverRedirectedEmbedURL, FileExtension, UniqueId } = item;

    let fileExtension = FileExtension ? FileExtension.toLowerCase() : FileExtension;
    let itemUrl = serverRedirectedEmbedURL ? serverRedirectedEmbedURL : Path;

    if (["msg", "txt"].indexOf(fileExtension) !== -1) {
        itemUrl += `${itemUrl.indexOf('?') !== -1 ? '&' : '?'}csf=1&web=1`;
    }

    if(fileExtension === 'pdf') {
        const siteUrl = Path.split('/', 5).join('/')
        itemUrl = `${siteUrl}/_layouts/15/viewer.aspx?sourcedoc=${UniqueId}`;
    }

    const openDesktopOfficeApp = () => {
        let officeSchema = 'ms-word';
        switch (fileExtension) {
            case 'xlsx':
            case 'xls':
                officeSchema = 'ms-excel';
                break;
            case 'pptx':
            case 'ppt':
                officeSchema = 'ms-powerpoint';
        }

        const iframe = document.createElement("iframe");
        iframe.style.display = "none";
        iframe.src = `${officeSchema}:ofe|u|${Path}`;
        document.body.appendChild(iframe);
    }

    return (
        <>
            {["docx", "doc", "aspx", "xlsx", "xls", "pptx", "ppt", "pdf"].indexOf(fileExtension) !== -1 ?
                <Link 
                    href={`${itemUrl}${itemUrl.indexOf('?') !== -1 ? '&' : '?'}action=default&mobileredirect=true`} 
                    style={style} 
                    target='_blank' 
                    data-interception="off"
                    onClick={e => {
                        if (onClick) {
                            e.preventDefault();
                            onClick();
                        } else if (["docx", "doc", "xlsx", "xls", "pptx", "ppt"].indexOf(fileExtension) !== -1) {
                            e.preventDefault();
                            openDesktopOfficeApp();
                        }
                    }
                    }
                >
                    {children}
                </Link>
                :
                <Link
                    href={itemUrl}
                    style={style}
                    target='_blank'
                    data-interception="off"
                    onClick={e => {
                        if (onClick) {
                            e.preventDefault();
                            onClick();
                        }
                    }
                    }
                >
                    {children}
                </Link>
            }
        </>
    );
}

export default DocumentLink;