const SearchService = () => {

    const getSharePointDigest = async (serverRelativeUrl: string) => {
        const url = `${serverRelativeUrl}/_api/contextinfo`;
        const options = {
            method: 'POST',
            headers: {
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose'
            }
        };

        try {
            const response = await fetch(url, options);
            const data = await response.json();
            return data.d.GetContextWebInformation.FormDigestValue;
        } catch (error) {
            console.error(error);
        }
    }
   
    const get = async (searchReducer: any) => {

        const { kqlText, serverRelativeUrl,sort,workspacePath} = searchReducer;

        const url = `${serverRelativeUrl}/_api/search/postquery`;
        const digest = await getSharePointDigest(serverRelativeUrl);

        const options = {
            method: 'POST',
            headers: {
                'Accept': 'application/json;odata=verbose',
                'Content-Type': 'application/json;odata=verbose',
                'x-requestdigest': digest
            },
            body: JSON.stringify({
                "request": {
                    'Querytext': kqlText,
                    'SortList': {
                        'results': sort?sort:[]       
                      },
                    'RowLimit': 300,
                    'SelectProperties': {
                        'results': [
                            'Title',
                            'Path',
                            'Site',
                            'AuthorOWSTEXT',
                            'AuthorOWSUSER',
                            'LegacyAuthorOWSTEXT',
                            'LegacyDocNumOWSTEXT',
                            'FileExtension',
                            'LastModifiedTime',
                            'ModifiedOWSDATE',
                            'ACMatterCode',
                            'OWS_MATTERCODE',
                            'UIVersionStringOWSTEXT',
                            'ACDocumentId',
                            'owstaxIdDocumentType',
                            'ows_DocumentType',
                            'Edit',
                            'Size',
                            'IconUrl',
                            'Filename',
                            'serverRedirectedPreviewURL',
                            'serverRedirectedEmbedURL',
                            'RefinableString05',
                            'ROAMSubject',
                            'IntappFromOWSTEXT',
                            'IntappToOWSMTXT',
                            'IntappDateSentOWSDATE',
                            'IntappDateReceivedOWSDATE',
                            'IntappHasAttachmentsOWSBOOL',
                            'Author',
                            'ContentType'
                        ]
                    }
                }
            })
        };

        try {
            const result = []
            if(kqlText!="")
            {
            const response = await fetch(url, options);
            const jsonData = await response.json();

            const rawData = jsonData.d.postquery.PrimaryQueryResult.RelevantResults.Table.Rows.results;

            for (let i = 0; i < rawData.length; i++) {
                const item = {} as any;

                for (let j = 0; j < rawData[i].Cells.results.length; j++) {
                    
                    const field = rawData[i].Cells.results[j];
    
                    item[field.Key] = field.Value;
                }

                result.push(item);
            }
            }
            console.log(result);
            return result;

        } catch (error) {
            console.error(error);

            return [];
        }
    }

    return {
        get,
        getSharePointDigest
    }
}

export default SearchService;