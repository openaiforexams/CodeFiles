import * as React from 'react';
import { SearchContext } from '../../hooks/SearchContext';
import { TaxonomyPicker, IPickerTerms } from "@pnp/spfx-controls-react/lib/TaxonomyPicker";
export interface IDocumentTypeFilter {
  context: any
  termID:string
}

//type PartialTermInfo = IPickerTerms["initialValues"];
const DocumentTypeFilter = ({ context ,termID}: IDocumentTypeFilter) => {
  const [defaultDocumentType, setDefaultDocumentType]= React.useState<IPickerTerms | undefined>([]);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  const [termSetID, setTermSetID]= React.useState<string>(undefined);
  let initialTerms: IPickerTerms = [];

  React.useEffect(() => {
    setTermSetID(termID);
    if (searchReducer.lastActionType == 'load' &&
      searchReducer.filters &&
      searchReducer.filters.DocumentTypeFilter &&
      searchReducer.filters.DocumentTypeFilter.jsonValues
    ) {
      setTermSetID(undefined);
      initialTerms=searchReducer.filters.DocumentTypeFilter.jsonValues as IPickerTerms;
      setDefaultDocumentType(initialTerms);
      setTermSetID(termID);

    } else if(searchReducer.lastActionType == 'load'||searchReducer.lastActionType == 'clear') {
      setTermSetID(undefined);
      initialTerms= [];
      setDefaultDocumentType(initialTerms);
      setTermSetID(termID);
    }

  }, [searchReducer,defaultDocumentType,termSetID])


 
  const updateKqlQuery = (terms: IPickerTerms) => {

    let kqlText = '';
  
    for (let i = 0; i < terms.length; i++) {
      kqlText += `owstaxIdDocumentType:${terms[i].key} ${i < terms.length - 1 ? ` OR ` : ''}`;
    }
    dispatchSearchReducer({ type: 'DocumentTypeFilter', payload: { kqlText, jsonValues: terms } });
  }

  return (
    <div>
    {
   termSetID && defaultDocumentType &&
  <TaxonomyPicker 
  allowMultipleSelections={true}
  termsetNameOrID={termSetID}//"81302116-e1b4-4f4c-8207-6ff6cf555c10"
  panelTitle="Select Document Type"
  label="Document Type"
  context={context}
  initialValues={defaultDocumentType}
  onChange={updateKqlQuery}
 
  
  
/>
 
  
  }
    </div>
  );
}

export default DocumentTypeFilter;