import * as React from 'react';

import { SearchContext } from '../../hooks/SearchContext';

import { DetailsList, DetailsListLayoutMode, IColumn, SelectionMode } from '@fluentui/react/lib/DetailsList';
import { mergeStyles, mergeStyleSets } from '@fluentui/react/lib/Styling';
import SearchService from '../../services/SearchService';
import { Dropdown, IconButton, IDropdownOption, IDropdownStyles } from '@fluentui/react';
import { getFileTypeIconProps } from '@fluentui/react-file-type-icons';
import Pagination from '../paginationComponents/pagination';
import { initializeFileTypeIcons } from '@fluentui/react-file-type-icons';
import styles from "../AcSearch.module.scss";
import Spinner from '../loaderComponents/loader'
import FilePreviewComponent from './FilePreviewComponent';
import SortingDropdown from './SortingDropdown'
let PageSize = 30;
import DocumentLink from './DocumentLink';
import DocumentLocation from './DocumentLocation';

export const DefaultSearchResultsComponent = () => {
  const [searchResults, setSearchResults] = React.useState([]);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  const [searchResultsAll, setSearchResultsAll] = React.useState([]);
  const [loading, setloading] = React.useState(Boolean);
  const [currentPage, setCurrentPage] = React.useState(1);
  const [previewItem, setPreviewItem] = React.useState(null);
  const [columns, setColumns] = React.useState<IColumn[]>([]);
  const refItems = React.useRef(searchResults);
  const refItemscolums =React.useRef(columns);
  const classNames = mergeStyleSets({

    fileIconHeaderIcon: {

      padding: 0,

      fontSize: '16px',

    },

    fileIconCell: {

      textAlign: 'center',

      selectors: {

        '&:before': {

          content: '.',

          display: 'inline-block',

          verticalAlign: 'middle',

          height: '100%',

          width: '0px',

          visibility: 'hidden',

        },

      },

    },

    fileIconImg: {

      verticalAlign: 'middle',

      maxHeight: '16px',

      maxWidth: '16px',

    }

  });
  const handleColumnClick = async (ev: React.MouseEvent<HTMLElement>, column: IColumn,) => {

    debugger;

    console.log("onsrot ", refItems.current);
    const newColumns = refItemscolums.current;
    //const currentColumn = newColumns[columnIndex];
    const currentColumn = newColumns.filter(currcol => column.key === currcol.key)[0];
    newColumns.forEach((col) => {

      if (col.key === currentColumn.key) {

        col.isSortedDescending = !col.isSortedDescending;

        col.isSorted = true;

      } else {

        col.isSorted = false;

        col.isSortedDescending = true;

      }

    });



    const sortedItems = refItems.current.sort((a, b) => {

      const aValue = a[column.fieldName];

      const bValue = b[column.fieldName];



      if (currentColumn.isSortedDescending) {

        return aValue > bValue ? -1 : 1;

      } else {

        return aValue > bValue ? 1 : -1;

      }

    });

    Promise.resolve().then(() => {

      setColumns(newColumns);

      const firstPageIndex = (currentPage - 1) * PageSize;

      const lastPageIndex = firstPageIndex + PageSize;

      const pagewiseDoc = sortedItems.slice(firstPageIndex, lastPageIndex);

      setSearchResults(pagewiseDoc);

    });
  };
  const dropdownStyles: Partial<IDropdownStyles> = {
   };
  const options: IDropdownOption[] = [

    { key: 'defaultView', text: 'Default View', isSelected: true }, 

    { key: 'emailView', text: 'Email View' }

  ];
  const formatAMPM = (date: Date) => {

    date.setHours(date.getHours());
    let hours = date.getHours();

    let minutes = date.getMinutes();

    let ampm = hours >= 12 ? "PM" : "AM";

    hours = hours % 12;

    hours = hours ? hours : 12;

    var minutesstr = minutes.toString().padStart(2, "0");

    let strTime = hours + ":" + minutesstr + " " + ampm;

    return (date.getDate()) + "/" + (date.getUTCMonth() + 1) + "/" + date.getUTCFullYear() + " " + strTime;

  };

  const openPreview = item => {
    const fileExtension = item.FileExtension ? item.FileExtension.toLowerCase() : '';
    const isFolder = item.ContentType === 'Folder';
    if (['aspx', 'doc', 'docx', 'pdf', 'xls', 'xlsx', 'ppt', 'pptx', 'msg', 'txt'].indexOf(fileExtension) !== -1 || isFolder) {
      setPreviewItem(item)
    }
  }

  const formatBytes = (a,b=2) =>
  {
    if(!+a)return"0 Bytes";
    const c=0>b?0:b,d=Math.floor(Math.log(a)/Math.log(1024));
    return`${parseFloat((a/Math.pow(1024,d)).toFixed(c))} ${["Bytes","KB","MB","GB","TB","PB","EB","ZB","YB"][d]}`;
  }

  const [selectedOptions, setSelectedOptions] = React.useState<string>(null);
  React.useEffect(() => {
    (async () => {
      // query change triggered by the reducer
      // reload the data
      initializeFileTypeIcons();
      setloading(true);
      const searchService = SearchService();
     
      if(searchReducer.searchResultView)
      {
        setSelectedOptions(searchReducer.searchResultView);
        refItemscolums.current=searchReducer.searchResultView=="emailView"?emailResultColumns:defaultResultColumns;
      }
      else{
        setSelectedOptions("defaultView");
        refItemscolums.current=defaultResultColumns;
      }
      const result = await searchService.get(searchReducer);      

      if (result != null) {

        setSearchResultsAll(result);
        refItems.current = result;
        const firstPageIndex = (currentPage - 1) * PageSize;
        const lastPageIndex = firstPageIndex + PageSize;
        const pagewiseDoc = result.slice(firstPageIndex, lastPageIndex);
        setSearchResults(pagewiseDoc);
      }
      setloading(false);
    }
    )();
  }, [searchReducer, currentPage,selectedOptions,columns]);
  const defaultResultColumns: IColumn[] = [
    {
      key: 'column1',
      name: 'Doc Type Icon',
      className: classNames.fileIconCell,
      iconClassName: classNames.fileIconHeaderIcon,
      iconName:'Page',
      fieldName: 'FileExtension',
      isIconOnly: true,
      minWidth: 120,
      maxWidth: 16,
      isResizable: true,
      onRender: (item) => (
        <IconButton
        
          iconProps={{ ...getFileTypeIconProps(item.ContentType === 'Folder' ? { type: 2, size: 16 } : { extension: item.FileExtension ? item.FileExtension.toLowerCase():'', size: 16 }) }}
          onClick={e => openPreview(item)}
        />
      ),
    },
    {
      key: 'column2',
      name: 'Document Name',
      fieldName: 'Filename',
      minWidth: 120,
      isResizable: true,
      isSorted: true,
      isSortedDescending: false,
      onColumnClick: handleColumnClick,
      onRender: (item) => (
          <div>
            <DocumentLink 
              item={item} 
              onClick={(['aspx', 'ASPX'].indexOf(item.FileExtension) !== -1 || item.ContentType === 'Folder') ? e => setPreviewItem(item) : null}
            >
            {item.Filename}
            </DocumentLink>
            {item.RefinableString05 != null && <IconButton iconProps={{ iconName: 'CheckedOutByYou12' }} style={{ width: "10px", height: "10px", marginLeft: "10px" }} />}
          </div>
      )
    },
    {
      key: 'column3',
      name: 'Document Number',
      fieldName: 'ACDocumentId',
      minWidth: 120,
      isResizable: true
    },
    {
       key: 'column4',
       name: 'Workspace Code',
       fieldName: 'ACMatterCode',
        minWidth: 100,
       isResizable: true
     },
    {
      key: 'column5',
      name: 'Version',
      fieldName: 'UIVersionStringOWSTEXT',
      minWidth: 60,
      isResizable: true
    }, {
      key: 'column6',
      name: 'Author',
      fieldName: 'AuthorOWSTEXT',
      minWidth: 100,
      isResizable: true,
      onRender: (item: any) => {
        return <>{(item.AuthorOWSTEXT) ? item.AuthorOWSTEXT : (item.LegacyAuthorOWSTEXT) ? item.LegacyAuthorOWSTEXT : item.Author}</>;
      }
    }, {
      key: 'column7',
      name: 'Document Type',
      fieldName: 'owstaxIdDocumentType',
      minWidth: 100,
      isResizable: true,
      onRender: (item: any) => {
        let docType="";
        if(item.owstaxIdDocumentType!=null)
        {
          
          docType=item.owstaxIdDocumentType.split(';')[1].split('|')[2];
        }
        return <div>{docType}</div>;
      }
    }, {
      key: 'column8',
      name: 'Date Modified',
      fieldName: 'ModifiedOWSDATE',
      minWidth: 120,
      isResizable: true,
      onRender: (item: any) => {
        return <span>{(item.ModifiedOWSDATE != '' && item.ModifiedOWSDATE != null) ? formatAMPM(new Date(item.ModifiedOWSDATE)) : ''}</span>;
      }
    }, {
      key: 'column9',
      name: 'File Size',
      fieldName: 'Size',
      minWidth: 60,
      isResizable: true,
      onRender: (item: any) => {
        return <>{formatBytes(item.Size)}</>;
      }
    },
    {
      key: 'column11',
      name: 'Location',
      fieldName: 'Path',
      minWidth: 80,
      isResizable: true,
      onRender: item => <DocumentLocation item={item} />
    }
  ];
  const emailResultColumns : IColumn[]= [
    {
      key: 'column1',
      name: 'Doc Type Icon',
      className: classNames.fileIconCell,
      iconClassName: classNames.fileIconHeaderIcon,
      iconName:'Page',
      fieldName: 'FileExtension',
      isIconOnly: true,
      minWidth: 16,
      maxWidth: 16,
      isResizable: true,
      onRender: (item) => (
        <IconButton
          iconProps={{ ...getFileTypeIconProps(item.ContentType === 'Folder' ? { type: 2, size: 16 } : { extension: item.FileExtension, size: 16 }) }}
          onClick={e => openPreview(item)}
        />
      ),
    },
    {
      key: 'column2',
      name: 'Name',
      fieldName: 'Filename',
      minWidth: 100,
      isResizable: true,
      onRender: (item) => (
          <div>
            <DocumentLink 
              item={item} 
              onClick={(['aspx', 'ASPX'].indexOf(item.FileExtension) !== -1 || item.ContentType === 'Folder') ? e => setPreviewItem(item) : null}
            >
            {item.Filename}
            </DocumentLink>
            {item.RefinableString05 != null && <IconButton iconProps={{ iconName: 'CheckedOutByYou12' }} style={{ width: "10px", height: "10px", marginLeft: "10px" }} />}
          </div>
      )
    },
    {
      key: 'column3',
      name: 'From',
      fieldName: 'IntappFromOWSTEXT',
      minWidth: 60,
      isResizable: true
    },
    {
      key: 'column4',
      name: 'To',
      fieldName: 'IntappToOWSMTXT',
      minWidth: 60,
      isResizable: true
    },
    {
      key: 'column5',
      name: 'Document Number',
      fieldName: 'ACDocumentId',
      minWidth: 120,
      isResizable:true
    },
    {
      key: 'column6',
      name: 'Subject',
      fieldName: 'ROAMSubject',
      minWidth: 60,
      isResizable: true
    }, 
    {
      key: 'column7',
      name: 'Workspace Code',
      fieldName: 'ACMatterCode',
      minWidth: 120,
      isResizable: true
    }, 
    {
      key: 'column8',
      name: 'Date Received',
      fieldName: 'IntappDateReceivedOWSDATE',
      minWidth: 30,
      isResizable: true,
      onRender: (item) => (
        <>{item.IntappDateReceivedOWSDATE ? `${new Date(item.IntappDateReceivedOWSDATE).toLocaleDateString('en-GB')}`:''}</>
      )
    }, 
    {
      key: 'column9',
      name: 'File Size',
      fieldName: 'Size',
      minWidth: 50,
      isResizable: true,
      onRender: (item: any) => {
        return <>{formatBytes(item.Size)}</>;
      }
    }, 
    {
      key: 'column10',
      name: 'Has Attachments',
      fieldName: 'IntappHasAttachmentsOWSBOOL',
      minWidth: 60,
      isResizable: true,
      onRender: (item) => (
        <>{item.IntappHasAttachmentsOWSBOOL == 1 ? 'Yes':''}</>
      )
    },
    {
      key: 'column11',
      name: 'Location',
      fieldName: 'Path',
      minWidth: 80,
      isResizable: true,
      onRender: item => <DocumentLocation item={item} />
    }
  ];
  
  const updateKqlQuery = (event: React.FormEvent<HTMLDivElement>, option: IDropdownOption): void => {

    let kqlText = "";
    let Options = "";

    if (option) {
      Options = option.key as string;    //option.selected ? [...selectedOptions, option.key as string] :  selectedOptions.filter(key => key !== option.key);  
      setSelectedOptions(Options);
    }
    if (option.key as string == "emailView") {
      kqlText += '';
       dispatchSearchReducer({ type: 'ViewfileTypeFilter', payload: { kqlText, jsonValues: null },searchResultView:'emailView' });

      // changing to email view will also flip the restrictSearchTo filter to 'Email Only'
      kqlText += 'contenttype:"AC Email" AND FileExtension:"msg"';
      dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues: "Emails Only" as string }, searchResultView: 'emailView' });
    }
    else {
      kqlText += '';
      dispatchSearchReducer({ type: 'ViewfileTypeFilter', payload: { kqlText, jsonValues: null },searchResultView:'defaultView' });

      // changing to default view will also flip the restrictSearchTo filter to 'Email Only'
      kqlText +='contenttypeid:0x01010000F35FC355F0AE488312404DD8630FEA* OR contenttype:"AC Document Legacy" OR contenttype:"AC Email" OR contenttype:"AC Email Legacy"';
      dispatchSearchReducer({ type: 'restrictSearchTo', payload: { kqlText, jsonValues:'Documents & Emails' as string},searchResultView:'defaultView'});
    }
  }

  return (
    <>
      <div style={{ display: previewItem ? 'none' : 'block'}}>
        

          <h2>Search Results:</h2>
          <div className="ms-Grid">
          <div className="ms-Grid-row">
            <div className="ms-Grid-col ms-sm6 ms-md4 ms-lg3" style={{float:"right"}}>
            <SortingDropdown/>
            </div>
            <div className="ms-Grid-col ms-sm6 ms-md4 ms-lg3" style={{float:"right"}}>
            <Dropdown
              placeholder="Select options"
              label="View Type"
              options={options}
              selectedKey={selectedOptions}
              styles={dropdownStyles}
              onChange={updateKqlQuery}
            />
            </div>
          </div>
</div>
          <div style={{position:"relative"}}>
      <div>
          <DetailsList
          
            items={searchResults}
            columns={refItemscolums.current}
            selectionMode={SelectionMode.none}
                        layoutMode={DetailsListLayoutMode.fixedColumns} />
           {searchResults.length==0?<div style={{textAlign:"center",width:"100%"}}> No results found for search criteria</div>:null}
        </div>
        <div className={styles.pagnizationContainer}>
          <Pagination
            className="pagination-bar"
            currentPage={currentPage}
            totalCount={searchResultsAll.length}
            pageSize={PageSize}
            onPageChange={(page) => setCurrentPage(page)}
          />
        </div>
        <div>
          <div style={window.location.href.toLowerCase().indexOf('workbench')>0?{ display: "block"}:{display:"none"}}>
            <h2>Debug Data:</h2>

            {searchReducer &&
              <code>
                <pre>
                  {JSON.stringify(searchReducer, null, 2)}

                </pre>
              </code>}
            <div style={{ display: 'flex', flexWrap: 'nowrap' }}>
              KQL Query: <br />{searchReducer.kqlText}
            </div>
          </div>
        </div>
        {loading ? <Spinner></Spinner> : ""}
        </div>
      </div>
      {previewItem && <FilePreviewComponent item={previewItem} onClose={e => setPreviewItem(null)} />}
    </>
  );
}