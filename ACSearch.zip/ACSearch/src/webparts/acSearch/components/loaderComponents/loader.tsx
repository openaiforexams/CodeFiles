import * as React from 'react';
import { Spinner, SpinnerSize } from '@fluentui/react/lib/Spinner';
import styles from "../AcSearch.module.scss";
const spinner= ()=>{
    return(

        <div className={styles.loaderContainer}>

          <Spinner  labelPosition='top' size={SpinnerSize.large} styles={{root:{justifyContent:"flex-end" },label: { fontSize: "14px" } }} label="Request is getting processed, please wait for few seconds." ariaLive="assertive" />

        </div>
        /*<div>
        <Spinner label="Loading items..." size={SpinnerSize.large} />
        </div>*/
    )
} 
export default spinner