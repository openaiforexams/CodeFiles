import * as React from 'react';
import { SearchContext } from '../../hooks/SearchContext';
import { PrimaryButton } from '@fluentui/react/lib/Button';
import { Dialog, DialogType, DialogFooter } from '@fluentui/react/lib/Dialog';
import { TextField } from '@fluentui/react/lib/TextField';
import UserSearchQueryService from '../../services/UserSearchQueryService';

const dialogContentProps = {
    type: DialogType.largeHeader,
    title: 'Confirm Delete',
    subText: '',
};

const DeleteUserQueryComponent = ({context}:any) => {
    const [openDialog, setOpenDialog] = React.useState(false);
    const { searchReducer,dispatchSearchReducer } = React.useContext(SearchContext);
    const deleteUserQuery = async () => {
        const userSerchService = UserSearchQueryService(context);
       await  userSerchService.deleteSearchQuery(searchReducer.loadedID, searchReducer);
        setOpenDialog(!openDialog);
        const data = await userSerchService.getUserQueriesListUsingListRestAPI(searchReducer);
        const list = [];
        for (let i = 0; i < data.length; i++) {
            list.push({ key: data[i].Id, text: data[i].Title });
        }
        dispatchSearchReducer({type:"userquerylist",jsonValue:list});
        let  kqlText ="";
        dispatchSearchReducer({ type: 'clear', payload: {kqlText, jsonValues:''}});
    }

    return (
        <>
            <PrimaryButton text="Delete" onClick={e => setOpenDialog(!openDialog)} disabled={!searchReducer.loadedID}/>
            <Dialog
                hidden={!openDialog}
                onDismiss={e => setOpenDialog(!openDialog)}
                dialogContentProps={dialogContentProps}            >
                <div>Are you sure you want to delete this query <b>"{searchReducer.loadedQueryName}"</b></div>
                <DialogFooter>
                    <PrimaryButton onClick={deleteUserQuery} text="Delete" />
                    <PrimaryButton onClick={e => setOpenDialog(!openDialog)} text="Cancel" />
                </DialogFooter>
            </Dialog>
        </>
    );
}

export default DeleteUserQueryComponent;