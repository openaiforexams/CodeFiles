import * as React from 'react';
import { SearchContext } from '../../hooks/SearchContext';
import { Dropdown, IDropdownStyles, IDropdownOption } from '@fluentui/react/lib/Dropdown';
import { Label, TextField } from '@fluentui/react';

const dropdownStyles: Partial<IDropdownStyles> = {

};

const options: IDropdownOption[] = [
  { key: 'Anywhere', text: 'Anywhere' },
  { key: 'Name', text: 'Name' },
  { key: 'Comments', text: 'Check-in Comments'},
  { key: 'Name / Comments', text: 'Name / Check-in Comments'}
];

const LookforFilter = () => {
  const [selectedOption, setSelectedOption] = React.useState<string>(null);
  const [textFieldValue, setTextFieldValue] = React.useState(null);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);

  React.useEffect(() => {

    if (searchReducer.lastActionType == 'load' &&
      searchReducer.filters &&
      searchReducer.filters.LookforFilter &&
      searchReducer.filters.LookforFilter.jsonValues
    ) {
      setTextFieldValue(searchReducer.filters.LookforFilter.jsonValues.textValue);

      setSelectedOption(searchReducer.filters.LookforFilter.jsonValues.dropdownValue);

    } else if (searchReducer.lastActionType == 'load'||searchReducer.lastActionType == 'clear') {
setTextFieldValue(null);
      setSelectedOption(null);
    }

  }, [searchReducer])

 
  const updateKqlQuery= (event: React.FormEvent<HTMLDivElement>, option: IDropdownOption): void => { 
    let kqlText = "";
    /* if(textFieldValue!=null){
      dispatchSearchReducer({ type: 'setKeywords', payload: { value: searchReducer.keywords!=null?searchReducer.keywords+" AND "+textFieldValue:null } })
    } */
    setSelectedOption(option.key as string);
    if (option.key as string  == "Name") {
      kqlText += `Filename:${textFieldValue}`;
      dispatchSearchReducer({ type: 'LookforFilter', payload: { kqlText, jsonValues:{dropdownValue: option.key as string ,textValue:textFieldValue}}})
    }
    else if(option.key as string== "Comments") {
      kqlText += `RefinableString07:${textFieldValue}`;
      dispatchSearchReducer({ type: 'LookforFilter', payload: { kqlText, jsonValues:{dropdownValue: option.key as string,textValue:textFieldValue} }})
    }
    else if(option.key as string == "Name / Comments") {
      kqlText += `Filename:${textFieldValue} OR RefinableString07:${textFieldValue}`;
      dispatchSearchReducer({ type: 'LookforFilter', payload: { kqlText, jsonValues:{dropdownValue: option.key as string ,textValue:textFieldValue} }})
    }
    else{
      kqlText += `${textFieldValue}`;
      dispatchSearchReducer({ type: 'LookforFilter', payload: { kqlText, jsonValues: {dropdownValue: option.key as string ,textValue:textFieldValue} }});
     // dispatchSearchReducer({ type: 'setKeywords', payload: { value: searchReducer.keywords!=null?searchReducer.keywords+" AND "+textFieldValue:null } })
    }
  }
  const updateKqlQueryForTextBoxChange= (value) => { 
    setTextFieldValue(value);
    let kqlText = "";

    if (selectedOption  == "Name") {
      kqlText += `Filename:${value}`;
      dispatchSearchReducer({ type: 'LookforFilter', payload: { kqlText, jsonValues:{dropdownValue: selectedOption ,textValue:value}}})
    }
    else if(selectedOption== "Comments") {
      kqlText += `RefinableString07:${value}`;
      dispatchSearchReducer({ type: 'LookforFilter', payload: { kqlText, jsonValues:{dropdownValue: selectedOption,textValue:value} }})
    }
    else if(selectedOption == "Name / Comments") {
      kqlText += `Filename:${value} OR RefinableString07:${value}`;
      dispatchSearchReducer({ type: 'LookforFilter', payload: { kqlText, jsonValues:{dropdownValue: selectedOption ,textValue:value} }})
    }
    else{
      kqlText += `${value}`;
      dispatchSearchReducer({ type: 'LookforFilter', payload: { kqlText, jsonValues: {dropdownValue: selectedOption ,textValue:value} }});
     // dispatchSearchReducer({ type: 'setKeywords', payload: { value: searchReducer.keywords!=null?searchReducer.keywords+" AND "+value:null } })
    }
  }

  return (
< div className = "ms-Grid" > <div className="ms-Grid-row">
<div className="ms-Grid-col ms-sm12 ms-md12 ms-lg12">
  <Label>Look For</Label>
  </div>
    <div className="ms-Grid-col ms-sm6 ms-md6 ms-lg6">
    <TextField            
            styles={{ root: { borderRadius: "0px", width: '100%' } }}           
            onChange={(e, value) =>{updateKqlQueryForTextBoxChange(value)}}
            value={textFieldValue || ''}
            defaultValue={textFieldValue}
        />
  </div>
    <div className="ms-Grid-col ms-sm12 ms-md12 ms-lg6">
        <Dropdown placeholder="Select options"
            disabled={textFieldValue==null} 
            options={options}
            selectedKey={selectedOption}
            styles={dropdownStyles}
            onChange={updateKqlQuery}/>
    </div>
</div>
</div>


  );
}

export default LookforFilter;