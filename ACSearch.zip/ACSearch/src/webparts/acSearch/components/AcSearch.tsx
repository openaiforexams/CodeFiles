import * as React from 'react';

import { SearchContext } from '../hooks/SearchContext';
import { SearchReducer } from '../hooks/SearchReducer';
import { SearchBoxComponent } from './searchBoxComponents/SearchBoxComponent';
import { DefaultSearchResultsComponent } from './searchResultComponents/DefaultSearchResultsComponent';

import AcSearchAdvancedOptions from './AcSearcAdvancedOptons';
import { BaseComponentContext } from '@microsoft/sp-component-base';
import styles from "./AcSearch.module.scss";
import { IAcSearchWebPartProps } from '../AcSearchWebPart';


export interface IAcSearchProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  context: BaseComponentContext;
  webpartProperities:IAcSearchWebPartProps;
}
const getParameterByName=(name, url = window.location.href)=> {

  name = name.replace(/[\[\]]/g, '\\$&');

  var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),

      results = regex.exec(url);

  if (!results) return null;

  if (!results[2]) return '';

  return decodeURIComponent(results[2].replace(/\+/g, ' '));

}
const AcSearch = ({ context,webpartProperities }: IAcSearchProps) => {
  
  const WorkSpacePath=getParameterByName("path");
  const [searchReducer, dispatchSearchReducer] = React.useReducer(SearchReducer, { 
    serverRelativeUrl: context.pageContext.web.serverRelativeUrl,
    absoluteUrl: context.pageContext.web.absoluteUrl,
    user: context.pageContext.user,   
    workspacePath:WorkSpacePath
  });

  
  return (
 
    
 
    <div className={styles.SearchContainer}>
      <div className={styles.title}> {WorkSpacePath!=null?"Workspace Content Search":"Global Content Search"}</div>
      <SearchContext.Provider value={{ searchReducer, dispatchSearchReducer }}>

        <SearchBoxComponent />

        <AcSearchAdvancedOptions context={context} webpartProperities={webpartProperities} WorkSpacePath={WorkSpacePath}/>

        <DefaultSearchResultsComponent />

      </SearchContext.Provider>
    </div>
  );
}

export default AcSearch;