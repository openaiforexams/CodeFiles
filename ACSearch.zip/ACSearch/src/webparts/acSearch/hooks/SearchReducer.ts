export const SearchReducer = (state: any, action: any) => {
    const { type, payload,searchResultView,sort,loadedID,loadedQueryName,jsonValue} = action;
    if(searchResultView){
        state={...state,searchResultView:searchResultView}
    }
    switch (type) {
        case 'setKeywords':
            state = {
                ...state,
                keywords: payload.value
            }
            break;
        case 'sort':state = {
            ...state,
            sort: sort!=null?[{

                'Property': sort,
        
                'Direction': sort=="LastModifiedTimeForRetention" || sort=="Created" ?"1":"0"
        
              }]:[]
        }
        break;
        case 'LookforFilter':
        case 'createdByFilter':
        case 'createdByFilterfreetext':            
        case 'DocumentTypeFilter':
        case 'documentIDFilter':
        case 'legacyDocumentNumberFilter':
        case 'restrictSearchTo':
        case 'clientFilter':
        case 'workspaceCodeFilter':
        case 'legacyauthorFilter':
        case 'authorFilter':
        case 'authorFilterfreetext':
        case 'ViewfileTypeFilter':
        case 'createdDateFilter':
        case 'modifiedDateFilter':
        case 'emailFromFilter':
        case 'emailToFilter':
        case 'emailDateReceivedFilter':
        case 'workspaceSearch':
        case 'emailDateSentFilter':
        case 'fileTypeFilter':
            if (payload.jsonValues != null) {
                state = {
                    ...state,
                    filters: {
                        ...state.filters,
                        [type]: payload
                    }
                }
            }
            else {
                let filterValue = { ...state.filters }
                delete filterValue[type]
                state = {
                    ...state,
                    filters: {
                        ...filterValue
                    }
                }
            }
            break;
       
        case 'load':
            const { filters, keywords } = payload.searchReducer;
            state = {
                ...state,
                filters,
                keywords,
                loadedID:loadedID,
                loadedQueryName:loadedQueryName
            } 
            //state = {...payload.searchReducer,loadedID:loadedID,loadedQueryName:loadedQueryName}
            break;
        case 'userquerylist':            
            state = {
                ...state,               
                userQueryList:jsonValue
            }            
            break;
        case 'clear':
        
        state = {
            ...state,
            filters:[],
            keywords:null,
            loadedID:loadedID,
            loadedQueryName:loadedQueryName
        } 
            //state = {...payload.searchReducer,loadedID:loadedID,loadedQueryName:loadedQueryName}
            break;
        default:
            state = {};
    }

    // generate the kql query text

    let kqlText = state.keywords || '*';
    if(state.workspacePath!=null)
    {
        let tempPath=state.workspacePath.indexOf("https://arthurcox.sharepoint.com")<0?"https://arthurcox.sharepoint.com"+state.workspacePath:state.workspacePath;
        kqlText +=` AND (Path:"*${tempPath}*")`
    }
    if (state.filters != undefined) {
        Object.entries(state.filters).forEach(([key, value]) => {
            const filter: { kqlText: string, jsonValue: any } = value as any;

            if (filter.kqlText && filter.kqlText != null) {
                kqlText += ` AND (${filter.kqlText})`
            }
        });
        
    }
    
    state = { ...state, kqlText, lastActionType: type }

    console.log('UPDATED STATE');
    console.log(state);

    return state;
}

