import * as React from 'react';

import { SearchContext } from '../../hooks/SearchContext';
import { Dropdown, IDropdownStyles, IDropdownOption } from '@fluentui/react/lib/Dropdown';

const dropdownStyles: Partial<IDropdownStyles> = {

};

const options: IDropdownOption[] = [
  { key: 'docx,doc', text: 'Word' }, //todo: account for doc not only docx
  { key: 'pptx,ppt', text: 'PowerPoint' }, //todo: account for ppt not only pptx
  { key: 'pdf', text: 'PDF' },
  { key: 'xlsx,xls', text: 'Excel' }, //todo: account for xls not only xlsx
  { key: 'txt', text: 'Text File' },
  { key: 'msg', text: 'Email File' },
  { key: 'one', text: 'OneNote' }
];

const FileTypeFilter = () => {
  const [selectedOptions, setSelectedOptions] = React.useState<string[]>([]);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);

  React.useEffect(() => {

    if (searchReducer.lastActionType == 'load' &&
      searchReducer.filters &&
      searchReducer.filters.fileTypeFilter &&
      searchReducer.filters.fileTypeFilter.jsonValues
    ) {

      setSelectedOptions(searchReducer.filters.fileTypeFilter.jsonValues);

    } else if (searchReducer.lastActionType == 'load'||searchReducer.lastActionType == 'clear') {

      setSelectedOptions([]);
    }

  }, [searchReducer])

  const updateKqlQuery = (event: React.FormEvent<HTMLDivElement>, option: IDropdownOption): void => {
    let Options=[];
    if (option) {
      Options=option.selected ? [...selectedOptions, option.key as string] :  selectedOptions.filter(key => key !== option.key);  
      setSelectedOptions(Options);
    }

    let kqlText = '';
    Options.map((item:any,i:number)=>{
      let tempKQL="";
      if(item.split(",").length>0){
        item.split(",").map((type:any,j:number)=>{
          tempKQL+=j==0?`FileExtension:${type}`:` OR FileExtension:${type}`;
        });
      }
      else{
        tempKQL+=`FileExtension:${item}`
      }
      kqlText += i == 0 ? tempKQL : ` OR ${tempKQL}`
    });

    dispatchSearchReducer({ type: 'fileTypeFilter', payload: { kqlText, jsonValues: Options } })
  }

  return (
    <Dropdown
      placeholder="Select options"
      label="File Type"
      multiSelect
      options={options}
      selectedKeys={selectedOptions}
      styles={dropdownStyles}
      onChange={updateKqlQuery}
    />
  );
}

export default FileTypeFilter;