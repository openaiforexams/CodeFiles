import * as React from 'react';
import { TextField } from '@fluentui/react/lib/TextField';
import { SearchContext } from '../../../hooks/SearchContext';

const TextFieldFilter = ({ managedProperties = [], filterName, label, placeholder, onChange = null }) => {
    const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
    const [textFieldValue, setTextFieldValue] = React.useState(null);

    React.useEffect(() => {

        if (searchReducer.lastActionType == 'load' &&
            searchReducer.filters &&
            searchReducer.filters[filterName] &&
            searchReducer.filters[filterName].jsonValues) {
            setTextFieldValue(searchReducer.filters[filterName].jsonValues);
        }
        else if (searchReducer.lastActionType == 'load'||searchReducer.lastActionType == 'clear') {
            setTextFieldValue(null);
        }
    }, [searchReducer])

    const updateValue = (value) => {
        setTextFieldValue(value)

        let kqlText = '';

        if (value && value != '') {

            for (let i = 0; i < managedProperties.length; i++) {
                const managedProp = managedProperties[i];

                let managedPropKqlText = value ? `${managedProp}:"${value}"` : '';

                kqlText += i == 0 ? managedPropKqlText : ` OR ${managedPropKqlText}`
            }
        }

        dispatchSearchReducer({ type: filterName, payload: { kqlText, jsonValues: value } });
        if(onChange) onChange();
    }

    return (
        <TextField
            label={label}
            styles={{ root: { borderRadius: "0px", width: '100%' } }}
            placeholder={placeholder || ''}
            onChange={(e, value) => updateValue(value)}
            value={textFieldValue || ''}
            defaultValue={textFieldValue}
        />
    );
}

export default TextFieldFilter;