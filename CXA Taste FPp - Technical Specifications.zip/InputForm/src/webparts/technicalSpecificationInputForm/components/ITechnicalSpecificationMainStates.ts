export interface ITechnicalSpecificationMainState{
    currentUser:any;
    title: string;
    description:string;
    isShowHomePage:boolean;
    isShowInputForm:boolean;
    isShowSearchForm:boolean;
}
