import * as React from 'react';
import { SearchContext } from '../../../hooks/SearchContext';
import { ITermInfo, ITermSetInfo, ITermStoreInfo } from "@pnp/sp/taxonomy";
import { ModernTaxonomyPicker } from "@pnp/spfx-controls-react/lib/ModernTaxonomyPicker";
import { ComboBox, IComboBoxOption, IComboBox, PrimaryButton } from '@fluentui/react';
import { ListItemPicker,ComboBoxListItemPicker  } from '@pnp/spfx-controls-react/lib/ListItemPicker';
import { sp } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { update } from '@microsoft/sp-lodash-subset';
export interface IComboBoxListItemPickerProps {
  context: any
  masterListURL:string
  listId:string
  keyColumnName:string
  textColumnName:string
  managedProperties:any
  filterName:string
  label:string
  placeholder:string
}



var arr = [];
let Comboboxoptions: any;
const ComboBoxListItemPickerComp = ({ context,masterListURL,listId,keyColumnName,textColumnName,managedProperties,filterName,label,placeholder}: IComboBoxListItemPickerProps) => {
  const [defaultCombobox, setDefaultCombobox] = React.useState([]);
  const [defatultComboboxOptions, setDefaultComboboxOptions] = React.useState([]);
  const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
  //let webURL = 'https://arthurcox.sharepoint.com.mcas.ms/sites/idspDEV'
  let webURL=masterListURL;
  React.useEffect( () => {
  

    if (searchReducer.lastActionType == 'load' &&
      searchReducer.filters &&
      searchReducer.filters[filterName] &&
      searchReducer.filters[filterName].jsonValues
    ) {

      const selectedItems= searchReducer.filters[filterName].jsonValues;
      setDefaultCombobox(selectedItems);

    }

  }, [searchReducer])

 
  
  const updateKqlQuery = (data: { key: string; name: string }[]) =>{  
   

    setDefaultCombobox(data);
 

    let kqlText = '';;
    for (let i = 0; i < data.length; i++) {

      for (let j = 0; j < managedProperties.length; j++) {
       const managedProp = managedProperties[j];

       let managedPropKqlText =`${managedProp}:"${data[i].key}"`;

       kqlText += i == 0 ? managedPropKqlText : ` OR ${managedPropKqlText}`
   }
   }    


    dispatchSearchReducer({ type: filterName, payload: { kqlText, jsonValues: data } })
  }
 
 

  return ( 
    <div>
      <ComboBoxListItemPicker 
      multiSelect
      listId={listId} 
      columnInternalName={textColumnName} 
      label={label} keyColumnInternalName={keyColumnName}
      filter={`${keyColumnName} ne null`}
      itemLimit={5} 
      onSelectedItem={updateKqlQuery}
      webUrl={masterListURL} 
      spHttpClient={context.spHttpClient} />
      </div>
  );
}

export default ComboBoxListItemPickerComp;