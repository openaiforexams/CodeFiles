import * as React from 'react';
import { PrimaryButton } from '@fluentui/react';
import DocumentLink from './DocumentLink';

const FilePreviewComponent = ({ item, onClose }) => {
    const { Path, serverRedirectedEmbedURL, FileExtension } = item

    let fileExtension = FileExtension ? FileExtension.toLowerCase() : FileExtension;
    let itemUrl = serverRedirectedEmbedURL ? serverRedirectedEmbedURL : Path;
    
    if (["msg", "txt"].indexOf(fileExtension) !== -1) {
        itemUrl += `${itemUrl.indexOf('?') !== -1 ? '&' : '?'}csf=1&web=1`;
    }

    return (
        <div style={{ width: '100%', position: 'relative', height: '1000px' }}>

            <div className="ms-Grid" dir="ltr" data-id='Controls Section' style={{ padding: '1rem 0' }}>
                <div className="ms-Grid-row">
                    <div className="ms-Grid-col ms-sm4" >
                        <PrimaryButton onClick={e => onClose()}>Go Back</PrimaryButton>
                    </div>
                    <div className="ms-Grid-col ms-sm4" style={{ textAlign: 'center' }}>
                        <div style={{ paddingBottom: '.3rem', fontWeight: 600 }}>Preview</div>
                    </div>
                    <div className="ms-Grid-col ms-sm4" style={{ textAlign: 'right' }}>

                        <DocumentLink item={item} style={{ marginRight: '1rem' }} >
                            Open
                        </DocumentLink>
                        <PrimaryButton onClick={e => onClose()}>Close</PrimaryButton>
                    </div>
                </div>
            </div>

            <iframe
                data-id='Preview Section'
                src={itemUrl}
                style={{ width: '100%', height: '100%', border: 0, display: 'block', margin: 'auto' }}
                title='AC File Preview'
                name='ac-file-preview'
            >
            </iframe>
        </div>
    );
}

export default FilePreviewComponent;