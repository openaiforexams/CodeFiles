import * as React from 'react';
import { useBoolean, useId } from '@fluentui/react-hooks'
import { SearchContext } from '../../../hooks/SearchContext';
import { DatePicker, mergeStyleSets, defaultDatePickerStrings, TextField, Callout, Separator, Link, PrimaryButton, IconButton } from '@fluentui/react';
import styles from '../../AcSearch.module.scss';
import * as moment from 'moment';

const DateFieldFilter = ({ managedProperties = [], filterName, label, onChange = null }) => {
    const [selectedDate, setSelectedDate] = React.useState(null);
    const { searchReducer, dispatchSearchReducer } = React.useContext(SearchContext);
    const [selectedFromDate, setSelectedFromDate] = React.useState(null);
    const [selectedToDate, setSelectedToDate] = React.useState(null);
    const [isCalloutVisible, { toggle: toggleIsCalloutVisible }] = useBoolean(false);
    const buttonId = useId(`${managedProperties && managedProperties.length ? managedProperties[0] : Math.random()}-button`);
    const cStyles = mergeStyleSets({
        callout: {
            width: 320,
            padding: '20px 24px',
        },
        title: {
            marginBottom: 12,
            fontWeight: 600
        },
        buttons: {
            display: 'flex',
            justifyContent: 'flex-end',
            marginTop: 20,
        },
    });
    React.useEffect(() => {
        if (searchReducer.lastActionType == 'load' &&
            searchReducer.filters &&
            searchReducer.filters[filterName] &&
            searchReducer.filters[filterName].jsonValues) {
            setSelectedDate(searchReducer.filters[filterName].jsonValues);
        }
        else if (searchReducer.lastActionType == 'load'||searchReducer.lastActionType == 'clear') {
            setSelectedDate(null);
        }
    }, [searchReducer])

    const updateKqlQuery = (filter) => {
        let kqlText = '';

        if (filter) {

            for (let i = 0; i < managedProperties.length; i++) {
                const managedProp = managedProperties[i];
                let managedPropKqlText = '';

                switch (filter) {
                    case "Today":
                        managedPropKqlText += `${managedProp}="today"`;
                        break;
                    case "Yesterday":
                        managedPropKqlText += `${managedProp}="yesterday"`;
                        break;
                    case "Last 7 days":
                        managedPropKqlText += `${managedProp}=${moment().add(-7, 'd').format('YYYY/MM/DD')}..${moment().format('YYYY/MM/DD')}`;
                        break;
                    case "Last 30 days":
                        managedPropKqlText += `${managedProp}=${moment().add(-30, 'd').format('YYYY/MM/DD')}..${moment().format('YYYY/MM/DD')}`;
                }
                kqlText += i == 0 ? managedPropKqlText : ` OR ${managedPropKqlText}`
            }

        } else {
            kqlText = null
        }

        setSelectedDate(filter);
        dispatchSearchReducer({ type: filterName, payload: { kqlText, jsonValues: filter } });
        toggleIsCalloutVisible();
        if(onChange) onChange();
    }

    const updateKqlQueryBetween = () => {

        let kqlText = '';

        if (selectedFromDate || selectedToDate) {

            for (let i = 0; i < managedProperties.length; i++) {

                const managedProp = managedProperties[i];
                let managedPropKqlText = '';

                if (selectedFromDate && selectedToDate) {
                    managedPropKqlText = `${managedProp}=${moment(selectedFromDate).format('YYYY/MM/DD')}..${moment(selectedToDate).format('YYYY/MM/DD')}`;
                } else if (selectedFromDate) {
                    managedPropKqlText = `${managedProp}>=${moment(selectedFromDate).format('YYYY/MM/DD')}`;
                } else if (selectedToDate) {
                    managedPropKqlText = `${managedProp}<=${moment(selectedToDate).format('YYYY/MM/DD')}`;
                }

                kqlText += i == 0 ? managedPropKqlText : ` OR ${managedPropKqlText}`;
            }

        } else {
            kqlText = null;
        }

        setSelectedDate(moment(selectedFromDate).format('ll') + " - " + moment(selectedToDate).format('ll'));
        toggleIsCalloutVisible();
        dispatchSearchReducer({ type: filterName, payload: { kqlText, jsonValues: Date } });
        if(onChange) onChange();
    }

    const onChangeDateFrom = (date: Date) => {
        setSelectedFromDate(date);
        setSelectedToDate(moment().toDate());

    }
    const onChangeDateTo = (date: Date) => {
        setSelectedToDate(date);
    }


    const clearKqlQueryDate = () => {
        let kqlText = '';
        setSelectedFromDate(null);
        setSelectedToDate(null);
        setSelectedDate(null);
        dispatchSearchReducer({ type: filterName, payload: { kqlText, jsonValues: null } });
        toggleIsCalloutVisible();
    }

    return (
        <>
            <div>
                <TextField onClick={toggleIsCalloutVisible}
                    label={label || 'Date'}
                    id={buttonId}
                    value={selectedDate != null ? selectedDate : "Select Date"} iconProps={{ iconName: 'ChevronDown' }} readOnly />
                <IconButton style={selectedDate == null ? { display: "none" } : { display: "block" }} className={styles.dateFilterClear} onClick={clearKqlQueryDate} iconProps={{ iconName: 'Cancel' }} title="Clear" ariaLabel="Clear" />
            </div>
            {isCalloutVisible ? (

                <Callout
                    role="alertdialog"
                    className={cStyles.callout}
                    gapSpace={0}
                    target={`#${buttonId}`}
                    onDismiss={toggleIsCalloutVisible}
                    setInitialFocus
                >
                    <Link className={styles.filterLink} onClick={() => updateKqlQuery("Today")}>Today</Link>
                    <Link className={styles.filterLink} onClick={() => updateKqlQuery("Yesterday")}>Yesterday</Link>
                    <Link className={styles.filterLink} onClick={() => updateKqlQuery("Last 7 days")}>Last 7 days</Link>
                    <Link className={styles.filterLink} onClick={() => updateKqlQuery("Last 30 days")}>Last 30 days</Link>
                    <Separator />
                    <DatePicker
                        value={selectedFromDate}
                        placeholder="From"
                        ariaLabel="From"
                        maxDate={new Date()}
                        onSelectDate={onChangeDateFrom}
                        strings={defaultDatePickerStrings} />
                    <DatePicker
                        defaultValue={selectedToDate}
                        value={selectedToDate}
                        minDate={selectedFromDate}
                        maxDate={new Date()}
                        placeholder="To"
                        ariaLabel="To"
                        onSelectDate={onChangeDateTo}
                        strings={defaultDatePickerStrings} />
                    <div style={{ float: 'right' }}>
                        <PrimaryButton text='Apply' style={{ marginRight: "10px" }} disabled={selectedFromDate == null || selectedToDate == null} onClick={updateKqlQueryBetween} />
                        <PrimaryButton text='Clear' disabled={selectedDate == null} onClick={clearKqlQueryDate} />
                    </div>
                </Callout>

            ) : null}
        </>
    );
}

export default DateFieldFilter;